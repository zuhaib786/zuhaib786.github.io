"""Experimental scalar P1 slope proposals with an unconditional bound guard.

The guard preserves each admissible mean. It cannot repair an inadmissible
mean: the time integrator must reject that stage. Bounds are prescribed by
the problem, never estimated from a learned probability or mesh quantile.
This is not an Euler positivity or entropy-stability implementation.
"""

import numpy as np
import time


class InadmissibleMean(ValueError):
    """A candidate cannot be repaired by conservative slope scaling."""


def bound_theta(u, lower, upper, atol=1e-12):
    """Largest P1 slope coefficient satisfying bounds, up to roundoff.

Vertex bounds imply bounds throughout an affine P1 triangle. This claim
does not extend to higher degree polynomials from vertex sampling alone.
"""
    u = np.asarray(u, dtype=float)
    if u.ndim != 2 or u.shape[0] != 3 or not np.all(np.isfinite(u)):
        raise ValueError("expected a finite scalar P1 array with shape (3, K)")
    if not np.isfinite([lower, upper, atol]).all() or lower >= upper or atol < 0:
        raise ValueError("bounds must be finite and increasing; atol must be nonnegative")
    means = np.mean(u, axis=0)
    if np.any(means < lower - atol) or np.any(means > upper + atol):
        raise InadmissibleMean("candidate mean outside prescribed bounds; reject stage")
    delta = u - means
    ratio = np.ones_like(u)
    np.divide(np.maximum(upper - means, 0), delta, out=ratio, where=delta > 0)
    np.divide(np.minimum(lower - means, 0), delta, out=ratio, where=delta < 0)
    return np.clip(np.min(ratio, axis=0), 0, 1)


def scale_slopes(u, theta):
    means = np.mean(u, axis=0)
    result = means + theta * (u - means)
    # Preserve inactive cells bit for bit, including constants.
    result[:, theta == 1] = u[:, theta == 1]
    return result


def invariant_features(solver, u, lower, upper):
    """Local, vertex-order-invariant features with correctly paired face traces.

    The fixed physical range supplies the amplitude scale. Periodic neighbors
    use the solver's topology. Face quantities are pooled, not concatenated
    in local vertex order. No extrema elsewhere in the field enter the input.
    """
    u = np.asarray(u, dtype=float)
    if u.shape != (3, solver.K) or not np.isfinite(u).all():
        raise ValueError("features require finite scalar P1 values")
    if not np.isfinite([lower, upper]).all() or upper <= lower:
        raise ValueError("features require finite increasing physical bounds")
    scale = upper - lower
    means = np.mean(u, axis=0)
    gradient = np.einsum("ik,kid->kd", u, solver.basis_gradients)
    h = np.sqrt(solver.mesh.areas)
    jumps = np.zeros((solver.K, 3))
    mean_jumps = np.zeros_like(jumps)
    grad_jumps = np.zeros_like(jumps)
    for face in range(3):
        neighbors = solver.all_neighbors[:, face]
        valid = neighbors >= 0
        other = neighbors[valid]
        other_face = solver.all_neighbor_faces[valid, face]
        trace = u[[face, (face + 1) % 3], :][:, valid]
        opposite = np.stack([u[(other_face + 1) % 3, other], u[other_face, other]])
        jumps[valid, face] = np.max(np.abs(trace - opposite), axis=0) / scale
        mean_jumps[valid, face] = np.abs(means[valid] - means[other]) / scale
        grad_jumps[valid, face] = h[valid] * np.linalg.norm(
            gradient[valid] - gradient[other], axis=1
        ) / scale
    lengths = solver.mesh.edge_lengths
    return np.column_stack([
        (means - lower) / scale,
        np.ptp(u, axis=0) / scale,
        np.std(u, axis=0) / scale,
        h * np.linalg.norm(gradient, axis=1) / scale,
        np.max(jumps, axis=1), np.mean(jumps, axis=1),
        np.max(mean_jumps, axis=1), np.mean(mean_jumps, axis=1),
        np.max(grad_jumps, axis=1), np.mean(grad_jumps, axis=1),
        np.min(lengths, axis=1) / np.max(lengths, axis=1),
        np.mean(solver.all_neighbors < 0, axis=1),
    ])


class GuardedSlopeLimiter:
    """Use ``min(theta_ML, theta_bound)`` at every RK stage.

    ``proposal(solver, candidate)`` returns K coefficients, not probabilities.
    With no proposal this is the essential guard-only baseline. A nonfinite
    model coefficient falls back to the guard-only coefficient for that cell.
    Attempt counters include rejected steps; accepted-stage extrema and
    coefficients are recorded separately by the solver's returned history.
    """

    def __init__(self, lower, upper, proposal=None, atol=1e-12):
        bound_theta(np.full((3, 1), (lower + upper) / 2), lower, upper, atol)
        self.lower, self.upper = float(lower), float(upper)
        self.proposal, self.atol = proposal, float(atol)
        self.reset()

    def reset(self):
        self.rejected_steps = 0
        self.invalid_predictions = 0

    def apply(self, solver, u, *, initial=False):
        safe = bound_theta(u, self.lower, self.upper, self.atol)
        proposed = np.ones(solver.K)
        if self.proposal is not None and not initial:
            proposed = np.asarray(self.proposal(solver, u), dtype=float)
            if proposed.shape != (solver.K,):
                raise ValueError("slope proposal must have shape (K,)")
            invalid = ~np.isfinite(proposed)
            self.invalid_predictions += int(invalid.sum())
            proposed = np.where(invalid, 1.0, np.clip(proposed, 0, 1))
        theta = np.minimum(proposed, safe)
        result = scale_slopes(u, theta)
        stats = {
            "limited_fraction": float(np.mean(theta < 1 - 1e-12)),
            "mean_damping": float(np.mean(1 - theta)),
            "guard_fraction": float(np.mean(safe < proposed - 1e-12)),
            "minimum": float(np.min(result)), "maximum": float(np.max(result)),
        }
        return result, stats


class NumpySlopeModel:
    """Portable two-layer ReLU regressor; torch is needed only for training."""

    def __init__(self, path):
        with np.load(path, allow_pickle=False) as data:
            if int(data["schema_version"]) != 1:
                raise ValueError("unsupported slope feature schema")
            self.lower, self.upper = float(data["lower"]), float(data["upper"])
            self.w1, self.b1 = data["w1"], data["b1"]
            self.w2, self.b2 = data["w2"], data["b2"]
            self.jump_gate = bool(data["jump_gate"]) if "jump_gate" in data else False

    def __call__(self, solver, u):
        features = invariant_features(solver, u, self.lower, self.upper)
        hidden = np.maximum(features @ self.w1.T + self.b1, 0)
        prediction = np.clip((hidden @ self.w2.T + self.b2).ravel(), 0, 1)
        if self.jump_gate:
            # Consistency prior: suppress accumulated O(1) per-stage damping
            # on smooth fields. For smooth P1 traces, J=O(h^2), so J^2=O(h^4).
            # This is an architectural prior, not a full accuracy theorem.
            gate = np.minimum(features[:, 4], 1)**2
            return 1 - gate * prediction
        return prediction


def solve_guarded(solver, u0, final_time, controller, cfl=0.15,
                  max_seconds=60.0, max_retries=12):
    """SSP-RK3 using the existing DG spatial operator and guarded stages.

    Reject the whole step and halve dt if any stage mean is inadmissible.
    Never clip means or independently replace a cell's flux. Repeated failure
    raises an error; finite retries are not a proof of unconditional success.
    Returns the solution and all accepted-stage statistics. A solve resets
    controller counters. The caller must supply compatible boundary data.
    """
    if not np.isfinite(final_time) or final_time < 0:
        raise ValueError("final_time must be finite and nonnegative")
    if not np.isfinite(cfl) or cfl <= 0:
        raise ValueError("cfl must be finite and positive")
    if not isinstance(max_retries, int) or max_retries < 0:
        raise ValueError("max_retries must be a nonnegative integer")
    if not np.isfinite(max_seconds) or max_seconds <= 0:
        raise ValueError("max_seconds must be finite and positive")
    u = solver.project(u0) if callable(u0) else np.asarray(u0, dtype=float).copy()
    if u.shape != (3, solver.K):
        raise ValueError("initial data must have shape (3, K)")
    controller.reset()
    u, _ = controller.apply(solver, u, initial=True)
    current = 0.0
    history = []
    deadline = time.perf_counter() + max_seconds
    while current < final_time - 1e-14:
        nominal_dt = solver.stable_dt(cfl, current)
        if np.isposinf(nominal_dt):
            return u, history
        dt = min(nominal_dt, final_time - current)
        if not np.isfinite(dt) or dt <= 0:
            raise RuntimeError("invalid time step")
        for attempt in range(max_retries + 1):
            if time.perf_counter() >= deadline:
                raise TimeoutError("guarded solve exceeded wall-clock limit")
            if current + dt == current:
                raise RuntimeError("guarded time step collapsed")
            try:
                v1, s1 = controller.apply(solver, u + dt * solver.rhs(u, current))
                v2, s2 = controller.apply(
                    solver, .75 * u + .25 * (v1 + dt * solver.rhs(v1, current + dt)))
                trial, s3 = controller.apply(
                    solver, u / 3 + 2 / 3 * (v2 + dt * solver.rhs(v2, current + dt / 2)))
                break
            except InadmissibleMean as error:
                controller.rejected_steps += 1
                if attempt == max_retries:
                    raise RuntimeError("inadmissible mean after maximum step retries") from error
                dt *= .5
        u = trial
        current += dt
        history.append({"time": current, "dt": dt, "stages": [s1, s2, s3]})
    return u, history
