# Research assessment and guarded slope-limiter pilot

Reviewed 8–9 September 2026 against extension commit
`0771477133a9701cd81fcdbece51cbbcc0363c0f` and the original 2023 thesis PDF.

The existing study does not yet support a broadly superior learned limiter.
It does contain a useful representation ablation and a reproducible research
question: can learning reduce dissipation under a fixed numerical admissibility
requirement, beyond an identical guard without ML?

## What needed correcting in the blog

- **Thesis provenance:** Sections 5.7 and 5.9 explicitly restrict the implemented
  GNN to uniform 1D meshes. The thesis uses nine nodal inputs and includes evolved
  advection training data. The triangular P1 model, ten-feature schema, exact
  line/circle training, and later ablations are extensions.
- **One method, one set of claims:** historical smooth convergence belongs to
  different checkpoints/thresholds from the selected invariant-node model. The
  latter's reported smooth slope is 1.11 ± 0.02 and its calibration undershoot
  is 0.01447, above its own 0.01 gate. It is not safety-qualified.
- **Causal claims:** a negative data-v3 ladder does not eliminate distribution
  shift, label quality, capacity, or optimization. It changes several statistical
  properties and operating points. Small differences relative to an unpaired
  sample SD do not establish equivalence or identify a unique explanation.
- **Invariance:** graph-node equivariance differs from triangle-vertex symmetry.
  Invariant-node-v2 uses a global median/range, not the one-ring median claimed
  in the older article. Statistics alone do not uniquely determine face traces.
- **Classical baseline:** the triangular `minmod2d` path is a Barth–Jespersen-style
  neighbor-mean limiter. Zero violation in observed runs is not an unconditional
  maximum-principle theorem. Distinguish inspected, flagged and modified cells.
- **TV contradiction:** 14.24 is not the lowest Shu–Osher TV when a displayed row
  is 8.58. Physical waves can contribute legitimate TV; graph TV depends on mesh.
- **Reproducibility:** main is older than the experiment branch. The branch has
  implementations and summaries, but Git excludes raw `runs/` and checkpoints.
  Pin the branch's commit, link its summaries, and archive the underlying rows.
- **Unsafe next step:** quantile flagging forces a fixed proportion even in smooth
  flow. Neither a quantile nor normalized logits enforces a numerical bound.

## Implemented experiment

`tci/guarded.py` adds an optional path through `AdvectionDG2D.solve_guarded`.
It uses the existing spatial DG operator and SSP-RK3 coefficients. The historical
`solve` and indicator experiments retain their existing behavior.

1. A portable 12-input, 24-hidden-unit ReLU regressor predicts a continuous slope
   coefficient. Training uses torch; inference uses NumPy and an NPZ checkpoint.
2. Features use prescribed physical amplitude bounds, cell statistics,
   correctly paired face traces, pooled mean/gradient jumps, and shape context.
   Periodic adjacency is included. Features are invariant under cell and local
   triangle reorderings to floating-point tolerance and are local in the field.
3. An independent guard always computes the largest mean-preserving coefficient
   satisfying the physical scalar interval. The applied coefficient is the
   minimum of the learned proposal and the guard coefficient.
4. If a candidate mean lies outside the interval, the whole step is rejected and
   retried at half dt. After 12 retries, the solve fails explicitly. No cell mean
   is clipped and no cell flux is replaced independently of its neighbor.
5. Accepted-stage extrema, modified fraction, arithmetic mean damping, guard
   interventions, rejected attempts and invalid model predictions are measured.
   Nonfinite model outputs revert to the guard-only proposal; malformed shapes
   are programming errors. Nonfinite numerical states fail explicitly.

For affine scalar P1 fields, a vertex bound implies the same bound throughout
that cell, and scaling zero-mean deviations preserves the cell integral.
This is a conditional guarantee for accepted states, to `atol=1e-12` in the pilot.
It is not a proof of entropy stability, nonoscillation inside the interval,
completion of all solves, or Euler positivity. Appropriate CFL/boundary conditions
and an admissible mean remain essential. A finite retry policy is not a substitute
for an invariant-domain low-order fallback with conservative face coupling.

## Training protocol and limitations

The fixed dataset has 36 translated trajectories: periodic sinusoidal fields,
boxes, disks, and smooth tanh layers, on structured and perturbed Delaunay meshes
with n=6 or 10. Data seed: 20260908. Trajectories 0–27 train; 28–35 validate.
All eight forward-Euler snapshots of a trajectory stay together. States evolve
under the guard only. Slotted-disk rotation is absent from training.

The target minimizes P1 slope error to the nodal interpolant of the exact
translated reference at the candidate time. Mean error is independent of the
slope coefficient. On mean-zero P1 deviations, the mass matrix reduces to a
constant multiple of the Euclidean inner product, giving a closed-form target.
This target is one-step and off-policy; it need not minimize accumulated solver
error. It does not train on the model's own subsequent trajectory distribution.

Each of three initialization seeds (0, 1, 2) uses 300 full-batch Adam epochs with
lr=0.003. Select the lowest validation coefficient MSE, restore that epoch, save
its checkpoint and hash. Verify NumPy inference against torch. Data and split
remain fixed across seeds. No historical GNN checkpoint is used or overwritten.

## What was measured

Two 35-run pilots plus seven deterministic controls completed: **77/77 runs,
zero failures**. Each pilot has smooth periodic advection at n=8,16,32 and a full
slotted-disk revolution at n=8,12 on structured and perturbed Delaunay meshes
(mesh seed 71). Methods are classical minmod2d, guard-only and all three learned
initializations. The extra control replaces learning with the deterministic
jump gate described below. Per-run deadline: 60 seconds.

The first unconstrained regression damped almost every cell at every stage.
Its smooth refinement rate was about 0.99 and rotation errors exceeded the
classical baseline. That result is retained in `guarded-pilot`.

The exploratory revision imposes a consistency prior:

```
J_K = max face-trace jump / prescribed physical range
G_K = min(J_K, 1)^2
theta_ML = 1 - G_K * clip(network(features), 0, 1)
```

On a smooth P1 approximation with O(h²) trace jumps, this makes per-stage
learned damping O(h⁴). It is a design argument, not a full convergence theorem.
The revision was made after looking at the first pilot, so the reused test cases
are exploratory, not a pristine final holdout. Do not promote it by retuning on
these same cases.

| P1-reference L2 error | minmod2d | Guard only | Ungated ML, mean | Gated ML, mean | Deterministic jump gate |
|---|---:|---:|---:|---:|---:|
| Smooth, n=32 | 0.00598618 | 0.00061378 | 0.00865242 | 0.00061375 | 0.00061375 |
| Rotation, structured n=12 | 0.13946762 | 0.09452079 | 0.15221447 | 0.11975128 | 0.11975128 |
| Rotation, Delaunay n=12 | 0.14087027 | 0.09479030 | 0.15793266 | 0.12168791 | 0.12168791 |

These errors use the existing solver's exact mass-matrix norm of the difference
between P1 fields. The reference is the nodal interpolant (initial P1 state for
one full rotation), not a high-order quadrature norm against the continuous exact
solution. Smooth n=16→32 rates are approximately 0.94 for minmod2d, 2.15 for
guard-only, and 2.15 for the gated model. This supports further accuracy tests;
it does not alone establish true asymptotic convergence to the exact solution.

Every guarded accepted stage was in [-1.39e-17, 1]. No actual pilot step required
a retry; the rejection path is exercised by fault-injection tests. Smooth periodic
mass changes were at most 1.23e-15. Rotation has open boundaries: its mass change
includes numerical boundary transport and must not be reported as a conservation
residual. The stage-extrema records apply to the guarded methods; the historical
classical path only records final fields and last-stage flags.

The learned gated model is essentially the deterministic jump prior. It has not
shown a meaningful learned advantage. The guard alone is substantially more
accurate in both n=12 rotation cases. Keep the guarded interface and tests; do
not adopt either learned checkpoint as the new primary model. Timing records are
observational wall times from this local pilot, not isolated performance results.

`guarded-pilot-summary.json` records aggregates, including sample SDs. Raw JSON,
training splits and all six checkpoints are in `runs/guarded*-pilot/` locally and
in the website's downloadable pilot bundle. Run-time manifests record source
hashes as the prototype evolved; the bundle contains the consolidated source
that supports both variants. Its own SHA-256 manifest identifies those files.

## Reproduce

From this repository (Python >=3.10; ML optional dependencies needed for training):

```bash
python -m pip install -e '.[ml,dev]'
python -m pytest -q
python scripts/pilot_guarded_limiter.py --out runs/guarded-pilot
python scripts/pilot_guarded_limiter.py --out runs/guarded-gated-pilot --jump-gate
python scripts/pilot_guarded_limiter.py --out runs/guarded-gated-pilot --prior-only
```

To use a saved model without torch in the solver loop:

```python
from tci.guarded import GuardedSlopeLimiter, NumpySlopeModel

model = NumpySlopeModel('runs/guarded-gated-pilot/slope-seed-0.npz')
controller = GuardedSlopeLimiter(lower=0., upper=1., proposal=model)
u, stage_history = solver.solve_guarded(u0, final_time=1., controller=controller)
# Essential control: repeat with proposal=None.
```

## A defensible publication plan

The candidate contribution is **learning to reduce dissipation within a numerical
admissible set on unstructured meshes**, with evidence that ML improves on the
same admissibility mechanism alone. It is a hypothesis; neither this pilot nor
GAT-for-TCI by itself establishes novelty.

- First compare guard-only with a stronger accuracy-preserving classical limiter,
  e.g. [Moe–Rossmanith–Seal](https://arxiv.org/abs/1507.03024), using true quadrature
  errors, smooth extrema and a broader scalar suite. The current neighbor-mean
  baseline is too weak to support a broad superiority claim.
- Replace the one-step target with a rollout objective that measures later cell
  means and resolved structure, with an explicit cost for excess damping and
  inference. Include on-policy stage states; keep data and loss changes separate.
- Compare continuous ML, binary GNN plus the same guard, deterministic jump prior,
  and oracle controls with identical solver/degree/flux/CFL. If the model saturates
  to the prior again, reject the learned contribution.
- Before another acceptance test, freeze five initialization seeds, larger unseen
  mesh families/resolutions, held-out initial conditions and a precise protocol.
  A candidate gate could require no accepted-stage bound failures, no conservation
  residual above 1e-10 after boundary-flux accounting, asymptotic smooth order at
  least 1.8, at least 10% lower paired shock error than guard-only, no case more
  than 5% worse, and no more than 25% runtime overhead. These proposed gates have
  not been met or tested; set them before the next frozen run, not afterwards.
- Extend to higher p and Euler only after a scalar win. Use suitable quadrature
  sets and density/internal-energy or pressure admissibility, rather than applying
  scalar [0,1] clipping componentwise. Establish shared-flux fallback conservation.

Prior art already includes [neural TCI transfer](https://arxiv.org/abs/1912.09274),
[triangle symmetry](https://www.sciencedirect.com/science/article/abs/pii/S0045793026000265),
[mean-preserving bound limiting](https://doi.org/10.1007/s10915-011-9472-8),
[a posteriori DG subcell limiting](https://arxiv.org/abs/1406.7416), and
[ML with convex limiting](https://arxiv.org/abs/2407.17214).
A literature review and the decisive controls above are necessary before making
an originality claim or choosing a publication venue.
