import numpy as np
import pytest

from tci.guarded import (GuardedSlopeLimiter, InadmissibleMean, bound_theta,
                         invariant_features, scale_slopes)
from tci.mesh import TriangleMesh, rectangular_mesh
from tci.solvers.dg2d import AdvectionDG2D


def test_random_slopes_preserve_means_and_entire_p1_bounds():
    rng = np.random.default_rng(19)
    means = rng.uniform(0, 1, 500)
    delta = rng.normal(size=(3, 500)) * 8
    u = means + delta - delta.mean(axis=0)
    limited = scale_slopes(u, bound_theta(u, 0, 1))
    np.testing.assert_allclose(limited.mean(axis=0), means, atol=3e-15)
    barycentric = rng.dirichlet(np.ones(3), 100)
    interior = barycentric @ limited
    assert limited.min() >= -1e-14 and limited.max() <= 1 + 1e-14
    assert interior.min() >= 0 and interior.max() <= 1


def test_guard_refuses_inadmissible_mean_instead_of_clipping():
    with pytest.raises(InadmissibleMean):
        bound_theta(np.full((3, 2), -0.1), 0, 1)
    with pytest.raises(ValueError):
        bound_theta(np.full((3, 2), np.nan), 0, 1)


def test_features_and_limiting_ignore_local_vertex_and_cell_order():
    mesh = rectangular_mesh(nx=4, ny=4)
    solver = AdvectionDG2D(mesh, periodic=(True, True))
    rng = np.random.default_rng(28)
    u = rng.uniform(.1, .9, (3, mesh.K))
    u = .5 + 2 * (u - u.mean(axis=0))
    order = rng.permutation(mesh.K)
    cells = mesh.cells[order].copy()
    values = u[:, order].copy()
    for k in range(mesh.K):
        shift = k % 3
        cells[k] = np.roll(cells[k], shift)
        values[:, k] = np.roll(values[:, k], shift)
    changed = AdvectionDG2D(TriangleMesh(mesh.points, cells), periodic=(True, True))
    np.testing.assert_allclose(invariant_features(changed, values, 0, 1),
                               invariant_features(solver, u, 0, 1)[order], atol=1e-14)
    np.testing.assert_allclose(bound_theta(values, .2, .8),
                               bound_theta(u, .2, .8)[order], atol=1e-14)


def test_remote_extremum_cannot_rescale_local_features():
    solver = AdvectionDG2D(rectangular_mesh(nx=5, ny=5))
    u = solver.project(lambda x, y: .2 + .3 * x)
    local = invariant_features(solver, u, 0, 1)[0]
    u[:, -1] = 100
    np.testing.assert_array_equal(invariant_features(solver, u, 0, 1)[0], local)


def test_guard_remains_active_when_model_says_no_limiting():
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2))
    u = np.tile([-.2, .5, 1.2], (solver.K, 1)).T
    controller = GuardedSlopeLimiter(0, 1, lambda s, u: np.ones(s.K))
    result, stats = controller.apply(solver, u)
    assert result.min() >= 0 and result.max() <= 1
    assert stats["guard_fraction"] == 1


def test_bad_model_output_falls_back_but_wrong_shape_fails():
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2))
    u = np.full((3, solver.K), .5)
    guard = GuardedSlopeLimiter(0, 1, lambda s, u: np.full(s.K, np.nan))
    result, _ = guard.apply(solver, u)
    np.testing.assert_array_equal(result, u)
    assert guard.invalid_predictions == solver.K
    guard.proposal = lambda s, u: np.ones((s.K, 1))
    with pytest.raises(ValueError, match="shape"):
        guard.apply(solver, u)


def test_periodic_discontinuity_is_conservative_and_every_stage_bounded():
    solver = AdvectionDG2D(rectangular_mesh(nx=6, ny=6), periodic=(True, True))
    u0 = solver.project(lambda x, y: ((x > .3) & (x < .6)).astype(float))
    guard = GuardedSlopeLimiter(0, 1)
    u, history = solver.solve_guarded(u0, .1, guard)
    assert abs(solver.integral(u) - solver.integral(u0)) < 1e-13
    assert history
    for step in history:
        assert len(step["stages"]) == 3
        for stage in step["stages"]:
            assert stage["minimum"] >= -1e-12 and stage["maximum"] <= 1 + 1e-12


def test_guard_only_preserves_smooth_interior_solution():
    solver = AdvectionDG2D(rectangular_mesh(nx=8, ny=8), periodic=(True, True))
    u0 = solver.project(lambda x, y: .5 + .1 * np.sin(2 * np.pi * x))
    expected = solver.solve(u0, .02, cfl=.15)
    actual, _ = solver.solve_guarded(u0, .02, GuardedSlopeLimiter(0, 1), cfl=.15)
    np.testing.assert_array_equal(actual, expected)


def test_stage_rejection_recomputes_from_last_accepted_solution(monkeypatch):
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2))
    guard = GuardedSlopeLimiter(0, 1)
    original = solver.rhs
    calls = []

    def faulty_once(u, time=0):
        calls.append(u.copy())
        if len(calls) == 1:
            return np.full_like(u, -1e6)
        return original(u, time)

    monkeypatch.setattr(solver, "rhs", faulty_once)
    u0 = np.full((3, solver.K), .5)
    u, history = solver.solve_guarded(u0, .01, guard)
    assert guard.rejected_steps == 1
    np.testing.assert_array_equal(calls[0], calls[1])
    np.testing.assert_allclose(u, u0, atol=1e-15)
    assert history[-1]["time"] == pytest.approx(.01)


def test_retry_limit_and_deadline_fail_explicitly(monkeypatch):
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2))
    monkeypatch.setattr(solver, "rhs", lambda u, time=0: np.full_like(u, -1e12))
    with pytest.raises(RuntimeError, match="maximum step retries"):
        solver.solve_guarded(np.full((3, solver.K), .5), .1,
                             GuardedSlopeLimiter(0, 1), max_retries=1)
    with pytest.raises(TimeoutError):
        solver.solve_guarded(np.full((3, solver.K), .5), .1,
                             GuardedSlopeLimiter(0, 1), max_seconds=1e-15)


def test_stationary_field_is_not_damped_by_model():
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2), velocity=(0., 0.))
    u0 = solver.project(lambda x, y: x)
    controller = GuardedSlopeLimiter(0, 1, lambda s, u: np.zeros(s.K))
    result, history = solver.solve_guarded(u0, 1., controller)
    np.testing.assert_array_equal(result, u0)
    assert history == []


def test_exported_gated_model_has_no_damping_on_continuous_affine_field(tmp_path):
    from tci.guarded import NumpySlopeModel

    path = tmp_path / "model.npz"
    np.savez(path, schema_version=1, lower=0., upper=1., jump_gate=True,
             w1=np.zeros((24, 12)), b1=np.ones(24),
             w2=np.zeros((1, 24)), b2=np.ones(1))
    model = NumpySlopeModel(path)
    solver = AdvectionDG2D(rectangular_mesh(nx=4, ny=4))
    u = solver.project(lambda x, y: .2 + .2*x + .3*y)
    np.testing.assert_array_equal(model(solver, u), np.ones(solver.K))
    u[:, 2] += .25
    theta = model(solver, u)
    assert theta.min() < 1
    assert np.all((theta >= 0) & (theta <= 1))
