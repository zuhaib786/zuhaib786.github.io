#!/usr/bin/env python
"""Reproducible CPU pilot: continuous slope learning versus the same guard alone.

This is a feasibility experiment, not a publication benchmark. Synthetic
translation trajectories train a small regressor. Slotted-disk rotation and
smooth convergence are held out. Every attempted benchmark is written to JSON.
"""

import argparse
import hashlib
import json
import platform
import subprocess
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from tci.evaluate2d import rotation_solver, slotted_disk, graph_total_variation
from tci.guarded import (GuardedSlopeLimiter, NumpySlopeModel, bound_theta,
                         invariant_features, scale_slopes)
from tci.indicators.classical2d import MinmodIndicator2D
from tci.mesh import rectangular_mesh, perturbed_delaunay_mesh
from tci.solvers.dg2d import AdvectionDG2D


def make_dataset(seed=20260908, trajectories=36):
    rng = np.random.default_rng(seed)
    x_rows, y_rows, groups = [], [], []
    for group in range(trajectories):
        n = (6, 10)[group % 2]
        mesh = (rectangular_mesh(nx=n, ny=n) if group % 3 == 0 else
                perturbed_delaunay_mesh(nx=n, ny=n, jitter=.15, seed=group + 100))
        velocity = rng.uniform(-1, 1, 2)
        phase = rng.uniform(0, 1, 2)
        width = rng.uniform(.08, .25)
        mode = group % 4

        def reference(x, y, t):
            xx = (x - velocity[0] * t - phase[0]) % 1
            yy = (y - velocity[1] * t - phase[1]) % 1
            if mode == 0:
                return .5 + .3 * np.sin(2 * np.pi * xx) * np.cos(2 * np.pi * yy)
            if mode == 1:
                return ((xx > .25) & (xx < .25 + width)).astype(float)
            if mode == 2:
                return ((xx - .5)**2 + (yy - .5)**2 < width**2).astype(float)
            return .5 + .4 * np.tanh(np.sin(2 * np.pi * xx) / (.02 + width))

        solver = AdvectionDG2D(mesh, velocity=velocity, periodic=(True, True))
        u = solver.project(lambda x, y: reference(x, y, 0))
        dt = solver.stable_dt(.15)
        t = 0.0
        # All snapshots from a trajectory stay together in the train/val split.
        for snapshot in range(8):
            candidate = u + dt * solver.rhs(u, t)
            target = solver.project(lambda x, y: reference(x, y, t + dt))
            delta = candidate - candidate.mean(axis=0)
            ref_delta = target - target.mean(axis=0)
            denominator = np.sum(delta**2, axis=0)
            theta = np.ones(solver.K)
            np.divide(np.sum(delta * ref_delta, axis=0), denominator,
                      out=theta, where=denominator > 1e-20)
            # On mean-zero affine P1 modes, the mass-matrix quadratic is
            # proportional to this dot product. The mean error is independent
            # of theta. This is a one-step slope target, not a shock label.
            x_rows.append(invariant_features(solver, candidate, 0, 1))
            y_rows.append(np.clip(theta, 0, 1))
            groups.extend([group] * solver.K)
            u = scale_slopes(candidate, bound_theta(candidate, 0, 1))
            t += dt
    return np.concatenate(x_rows), np.concatenate(y_rows), np.asarray(groups)


def train_models(out, seeds, jump_gate=False):
    x, y, group = make_dataset()
    val = group >= 28
    np.savez_compressed(out / "training-data.npz", x=x, y=y, group=group, validation=val)
    # CPU, one thread, fixed data/split and independent initialization seeds.
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    xt, yt = torch.tensor(x, dtype=torch.float32), torch.tensor(y[:, None], dtype=torch.float32)
    gate = xt[:, 4:5].clamp(0, 1)**2

    def coefficients(model, mask):
        raw = model(xt[mask])
        return 1 - gate[mask] * raw.clamp(0, 1) if jump_gate else raw
    training = []
    for seed in seeds:
        torch.manual_seed(seed)
        model = nn.Sequential(nn.Linear(12, 24), nn.ReLU(), nn.Linear(24, 1))
        if jump_gate:
            # Start within the active interval so clipping does not kill all
            # output gradients at initialization.
            nn.init.zeros_(model[2].weight)
            nn.init.constant_(model[2].bias, .25)
        optimizer = torch.optim.Adam(model.parameters(), lr=.003)
        best, best_state, best_epoch = float("inf"), None, 0
        for epoch in range(300):
            model.train()
            prediction = coefficients(model, ~val)
            loss = torch.mean((prediction - yt[~val])**2)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            model.eval()
            with torch.no_grad():
                score = float(torch.mean((coefficients(model, val).clamp(0, 1) - yt[val])**2))
            if score < best:
                best, best_epoch = score, epoch + 1
                best_state = {key: value.detach().clone() for key, value in model.state_dict().items()}
        model.load_state_dict(best_state)
        path = out / f"slope-seed-{seed}.npz"
        np.savez(path, schema_version=1, lower=0., upper=1., jump_gate=jump_gate,
                 w1=model[0].weight.detach().numpy(), b1=model[0].bias.detach().numpy(),
                 w2=model[2].weight.detach().numpy(), b2=model[2].bias.detach().numpy())
        # Verify the runtime actually uses the trained weights correctly.
        exported = NumpySlopeModel(path)
        numpy_prediction = np.clip((np.maximum(x @ exported.w1.T + exported.b1, 0)
                                    @ exported.w2.T + exported.b2).ravel(), 0, 1)
        if jump_gate:
            numpy_prediction = 1 - np.clip(x[:, 4], 0, 1)**2 * numpy_prediction
        with torch.no_grad():
            np.testing.assert_allclose(numpy_prediction, coefficients(model, np.ones(len(x), dtype=bool))
                                       .clamp(0, 1).numpy().ravel(), atol=1e-6)
        training.append({"seed": seed, "best_epoch": best_epoch, "validation_theta_mse": best,
                         "checkpoint": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    return {"data_seed": 20260908, "train_trajectories": 28, "validation_trajectories": 8,
            "train_cells": int((~val).sum()), "validation_cells": int(val.sum()),
            "data_sha256": hashlib.sha256((out / "training-data.npz").read_bytes()).hexdigest(),
            "guard_only_validation_theta_mse": float(np.mean((1 - y[val])**2)), "models": training}


def evaluate(out, training, max_seconds, prior_only=False):
    rows = []
    cases = [("smooth", "structured", n) for n in (8, 16, 32)]
    cases += [("rotation", mesh, n) for mesh in ("structured", "delaunay") for n in (8, 12)]
    methods = [("minmod", None), ("guard-only", None)]
    methods += [("learned", row["seed"]) for row in training["models"]]
    if prior_only:
        methods = [("jump-prior", None)]
    for problem, mesh_type, n in cases:
        for method, seed in methods:
            if problem == "rotation":
                solver = rotation_solver(n, mesh_type, seed=71)
                initial = solver.project(slotted_disk)
                exact = initial
                final_time = 1.
            else:
                solver = AdvectionDG2D(rectangular_mesh(nx=n, ny=n),
                                       velocity=(.8, .3), periodic=(True, True))
                initial = solver.project(lambda x, y: .5 + .25 * np.sin(2*np.pi*x) * np.cos(2*np.pi*y))
                final_time = .05
                exact = solver.project(lambda x, y: .5 + .25 * np.sin(2*np.pi*(x-.8*final_time))
                                        * np.cos(2*np.pi*(y-.3*final_time)))
            row = dict(problem=problem, mesh=mesh_type, mesh_seed=71, n=n, method=method, seed=seed)
            started = time.perf_counter()
            try:
                if method == "minmod":
                    result, history = solver.solve(initial, final_time, cfl=.15,
                                                    indicator=MinmodIndicator2D(), record_flags=True,
                                                    max_seconds=max_seconds)
                    row["limited_fraction_final_stages"] = float(np.mean([flags.mean() for _, flags in history]))
                    row["stage_bounds_checked"] = False
                else:
                    proposal = NumpySlopeModel(out / f"slope-seed-{seed}.npz") if method == "learned" else None
                    if method == "jump-prior":
                        proposal = lambda s, u: 1 - np.minimum(invariant_features(s, u, 0, 1)[:, 4], 1)**2
                    controller = GuardedSlopeLimiter(0, 1, proposal)
                    result, history = solver.solve_guarded(initial, final_time, controller, max_seconds=max_seconds)
                    stages = [stage for step in history for stage in step["stages"]]
                    for metric in ("limited_fraction", "mean_damping", "guard_fraction"):
                        row[metric] = float(np.mean([stage[metric] for stage in stages]))
                    row["stage_minimum"] = min(stage["minimum"] for stage in stages)
                    row["stage_maximum"] = max(stage["maximum"] for stage in stages)
                    row["rejected_steps"] = controller.rejected_steps
                    row["invalid_predictions"] = controller.invalid_predictions
                    row["stage_bounds_checked"] = True
                row.update(status="ok", l2_error=solver.l2_error(result, exact),
                           l1_mean_error=float(np.sum(solver.mesh.areas * np.abs(solver.cell_means(result-exact)))),
                           minimum=float(result.min()), maximum=float(result.max()),
                           mass_change=solver.integral(result)-solver.integral(initial),
                           graph_tv=graph_total_variation(solver.cell_means(result), solver.mesh))
            except (TimeoutError, RuntimeError, ValueError) as error:
                row.update(status="failed", error=f"{type(error).__name__}: {error}")
            row["runtime_s"] = time.perf_counter() - started
            rows.append(row)
            filename = "prior-evaluation.json" if prior_only else "evaluation.json"
            (out / filename).write_text(json.dumps(rows, indent=2) + "\n")
            print(json.dumps(row), flush=True)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("runs/guarded-pilot"))
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--max-seconds", type=float, default=60.)
    parser.add_argument("--jump-gate", action="store_true",
                        help="exploratory consistency revision after the ungated pilot")
    parser.add_argument("--prior-only", action="store_true",
                        help="evaluate the deterministic jump gate without training or ML")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if args.prior_only:
        evaluate(args.out, {"models": []}, args.max_seconds, prior_only=True)
        return
    manifest = {"experiment": "guarded-slope-pilot-v1", "python": platform.python_version(),
                "numpy": np.__version__, "torch": torch.__version__,
                "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
                "source_dirty": bool(subprocess.check_output(["git", "status", "--porcelain"], text=True)),
                "seeds": args.seeds, "max_seconds_per_case": args.max_seconds,
                "jump_gate": args.jump_gate,
                "evaluation_status": "exploratory reused pilot cases" if args.jump_gate else "initial pilot",
                "claim": "feasibility only; all methods must be compared with guard-only",
                "source_sha256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                                  for p in [Path(__file__), Path("tci/guarded.py"), Path("tci/solvers/dg2d.py")]}}
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    training = train_models(args.out, args.seeds, args.jump_gate)
    (args.out / "training.json").write_text(json.dumps(training, indent=2) + "\n")
    print(json.dumps(training), flush=True)
    evaluate(args.out, training, args.max_seconds)


if __name__ == "__main__":
    main()
