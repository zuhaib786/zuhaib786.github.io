# Time-relaxed transformer reconstruction

The first local transformer improved short-rollout decision regret, but some
seeds damaged smooth solutions during repeated use. Its fixed sharpening
control did too. Physical bounds alone allow large errors inside the interval.
This iteration corrects a numerical weakness in the action and extends the
state distribution used for training. It remains an experimental scalar P1
method, not a proof that transformers provide a superior limiter.

## Numerical correction

Let `P0` be the guard-only polynomial and `Pa` one of the six bounded,
mean-preserving reconstruction experts from
[the first experiment](stencil-transformer-v1.md). This controller uses

```
P = P0 + alpha * (Pa - P0)
alpha = min(0.25, dt * |velocity| / sqrt(area))
        * clip((J - 2*h^1.5)/(2*h^1.5), 0, 1)
h = sqrt(area)
```

Every expert already satisfies the prescribed physical interval. Their convex
blend also preserves the current mean and interval, up to roundoff. The bound
guard follows the selection and the integrator rejects inadmissible stage
means. The change tends to zero linearly with `dt` at fixed mesh before the
cap activates. This removes the time-step-independent repeated reset; it is
**not** an entropy, TVD, or full convergence proof. The stricter jump sensor
suppresses reconstruction on more smooth resolved cells. Its coefficient was
changed after the first experiment, so this is a new design, not an ablation
isolating the effect of time relaxation alone.

The integrator supplies each limiter call with the actual stage time and time
step, including shortened final steps and rejected-step retries. Existing
slope controllers ignore that context. Tests check the three stage times,
shortened final steps, linear dependence on `dt`, means, bounds and conservation.

The attention policy skips inference where the deterministic action scale is
zero. Four additional token channels encode the query and neighbor transport
rates and the scaled velocity difference. The schema has 22 channels. The
attention model has 6,725 parameters; the pooling comparison has 7,877. Invalid
network scores now propagate to the controller's guard fallback and are counted.

## Data and evaluation

The configuration is `configs/transport-transformer-v2.json`. The new random
seed is 20260911. The 36 training and 12 validation trajectories retain the six
analytic profile families and crossed mesh types/resolutions. Snapshots occur
at physical times 0, 0.08 and 0.24, spanning early and substantially evolved
states. Stages 1, 2 and 3 are represented. As before, a provisional attention
policy contributes a second set of training trajectories only.

Counterfactual labels still finish the actual remaining RK stages and extend
to eight steps in total. To avoid making nearly identical actions' scores
depend mainly on the time-step size, their area-normalized advantages are
also divided by the cell's deterministic action scale; exact no-action ties
remain zero. Targets use the same 1e-4 scaling, clipping, score loss and
validation regret checkpoint criterion as the first experiment. These are
single-cell interventions with guard-only continuation; repeated learned
actions and long-horizon decisions remain approximations in the objective.

The guard-state joint oracle diagnostic improves mean short-rollout squared
error by 0.174% on training trajectories and 0.211% on validation trajectories.
No sampled joint intervention makes that diagnostic worse; some are exact
no-ops. The smaller gains reflect much smaller allowed corrections and must
not be interpreted as a bound on full-simulation improvement.

The final suite has 99 runs, with three seeds for each architecture and the
same three numerical controls. New parameters are held out: smooth advection
at n=12,24,48; diamonds and rings at n=14,24; and a different slotted disk rotated
for 0.4 revolutions at n=14,24. Both structured and Delaunay meshes are included.
The field families are known from the first experiment; this is a fresh
parameter and mesh holdout, not a new external benchmark. Rotation remains
absent from training. Checkpoints and source hashes precede this evaluation.

Acceptance thresholds remain the same as in the first transformer experiment:
10% mean sharp-case L1 improvement over guard-only, no case more than 5% worse,
a positive mean gain over the best classical control per case, smooth final
order at least 1.8, mean runtime at most 1.25 times guard-only, plus bound,
conservation and quadrature tolerances. All three attention seeds must pass.
These requirements do not include an absolute smooth-error ratio check; that
comparison must also be inspected before considering deployment.

Timing is exploratory: runs are from one host, and some execution overlaps
other experiment work. Large overhead is meaningful for this prototype, but
precise speed claims require isolated repeated timing on a fixed deployment
platform. Numerical metrics are deterministic for these saved checkpoints and
the recorded environment; timings are not.

## Reproduce

```sh
.venv/bin/python -m pytest -q
.venv/bin/python -m scripts.train_transport_transformer --out runs/transport-transformer-reproduction
.venv/bin/python -m scripts.audit_stencil_data --run runs/transport-transformer-reproduction
.venv/bin/python -m scripts.plot_stencil_transformer --run runs/transport-transformer-reproduction
```

The run retains all selected checkpoints, both datasets, exact executed source,
raw metrics, final nodal fields, hashes, oracle diagnostics and the acceptance
decision. No checkpoint is silently substituted for an existing detector.

## Result and optimized implementation

All 99 solves finish. The [complete assessment](transformer-results.md) reports
every seed. Attention seed 0 nearly matches guard-only in mean sharp-case error,
but the other two are substantially worse. Two pooling seeds improve the mean
by 1.69% and 2.35%; neither exceeds the fixed numerical control. No learned model
passes all acceptance criteria.

The deterministic fixed reconstruction reduces mean sharp-case L1 error by
9.41%, with gains on all eight cases (5.79–16.08%), while matching tested smooth
accuracy. This gain is not due to learning. `FixedTransportSharpenLimiter`
specializes the same expert choice, avoiding unused candidates and token
construction. Inactive learned decisions also bypass feature encoding.

These performance changes follow the frozen numerical evaluation. The exact
original source remains archived, and `benchmark_transport_inference.py` compares
optimized results against saved fields on three predetermined cases, with three
timing repeats per method. Its source and measurements are archived separately.
The fixed controller is a useful numerical candidate with an explicit accuracy
and cost tradeoff; these scalar unit-square experiments do not prove general
superiority or satisfy the learned model's 10% mean-improvement target.
