# A local transformer for conservative reconstruction

This experiment tests a different action space and a different representation,
not just a larger discontinuity classifier. The earlier damping model could
only shorten the existing slope. Here a learned policy can also sharpen that
slope or replace it with a reconstruction from neighboring cell means.

The scope is scalar P1 DG advection on affine triangles in the unit square with
prescribed [0,1] bounds. It is not an Euler limiter, entropy-stable method, or established
publication-ready advance. Results and the adoption decision are in the
experiment's `summary.json`; the numerical controls remain available separately.

## Data model and numerical actions

Each query cell sees an unordered set of at most ten cells: itself and its
two-hop face neighbors. The 18 token channels contain relative displacement,
signed mean difference, gradient, paired face-trace jump, nodal range, relative
cell size, triangle aspect proxy, physical boundary fraction, central mean,
central cell size, velocity direction and magnitude, central jump and range,
and a query-cell flag. Coordinates use minimum-image periodic displacements.
Lengths are normalized by the query cell's square-root area and amplitudes by
the prescribed physical range. Padding is explicitly masked. There are no
global cell IDs or arbitrary positional embeddings.

Neighbor permutation and cyclic local vertex renumbering are tested. The
network is **not** exactly rotation equivariant; signed geometric quantities
are represented in the physical coordinate frame. Velocities are encoded at
time zero; the evaluated constant and rotational fields are autonomous. This
implementation does not support a time-dependent transport encoding.

Six experts share the current cell mean:

1. The existing physical bound guard.
2. A flat reconstruction.
3. The existing slope multiplied by 1.5.
4. The existing slope multiplied by 2.
5. A distance-weighted least-squares reconstruction from face-neighbor means.
6. Twice that least-squares slope.

The least-squares system uses a pseudoinverse at incomplete boundary stencils.
Every alternative blends with the current slope through the deterministic gate
`clip((J - 0.5*h^1.5)/(0.5*h^1.5), 0, 1)`, where `h=sqrt(area)` and `J` is the
maximum paired face jump. This gate suppresses reconstruction on sufficiently
smooth resolved fields. It is an accuracy prior, not an accuracy theorem.
Every candidate is mean-corrected and physically bound-scaled before selection;
the chosen candidate passes the bound guard again. No action can directly
change a cell mean or replace one side of a shared numerical flux.

Preserving cell means preserves the spatial scheme's conservation accounting.
For affine P1 elements, vertex bounds imply bounds throughout each triangle.
Future stage means can still become inadmissible: the existing integrator
rejects the whole step and retries with a smaller time step. Finite retries do
not prove unconditional success or entropy stability.

## Labels and splits

The corrected frozen run is `runs/stencil-transformer-v1b/`. The first attempt,
`runs/stencil-transformer-v1/`, was stopped before final evaluation after a data
audit found profile family correlated with mesh type. `ABORTED.json` records
why. Its data are not part of the corrected run. The corrected generator crosses
every training family with both mesh types and both resolutions, with a
regression test for this condition.

There are 36 training and 12 validation trajectories. All cells, snapshots and
counterfactual branches of a trajectory stay in that trajectory's split.
Training uses randomly phased sine products, rectangles, disks, tanh layers,
Gaussian peaks and oblique periodic strips, with random translation directions
and speeds. Meshes are structured or perturbed Delaunay at n=6,9. Random phases
and widths differ by trajectory. Validation tests new parameters within these
families; final evaluation also tests new shapes and a new velocity field.

Three snapshots per trajectory are spaced twelve RK steps apart and sample
stages 1, 2 and 3 respectively. Each candidate expert is applied to **one cell**.
The oracle completes the actual remaining SSP-RK3 stages using the original
step's accepted state, then advances seven further guard-only steps. Its target
is global area-integrated squared error against the analytic solution. Positive
composite quadrature supplies reference moments. Independent tests compare all
three stage-specific intervention costs with complete production-solver runs.

The oracle also measures the result of applying all independently winning
actions together. This is a feasible joint intervention diagnostic, not a
globally optimal action assignment. On the guard-generated states, its mean
short-rollout squared-error reduction is 4.72% on training trajectories and
5.13% on validation trajectories; every sampled joint intervention improves
that particular short rollout. This does not establish full-simulation gains.

A provisional attention model generates another 36 training trajectories using
the same parameters. These behavior-policy states are labeled and combined with
the guard-generated states. Validation data are never added to training.
The result contains 25,272 training rows and 4,212 validation rows. Training
statistics are computed only from valid tokens in training rows. Trajectory
weights give every training trajectory equal total weight despite different
mesh sizes and the added behavior-policy states.

Targets are per-cell-area action advantages over guard-only, scaled by 1e-4
and clipped to [-20,20]. Models minimize weighted score MSE. Checkpoints minimize
validation action regret, with score MSE breaking ties. A non-guard expert is
chosen only when its predicted scaled advantage exceeds 0.02. This is a
decision threshold, not a confidence certificate. Near-tie target noise is
audited separately by refining reference quadrature while fixing the state.

## Architecture comparison

The attention model is a small set transformer: 24 hidden channels, three
attention heads, one residual self-attention block, a residual feed-forward
block and a query-plus-masked-mean readout. It has 6,629 parameters. The pooling
ablation uses the same tokens, normalization, readout, labels and training
budget, but replaces token-to-token attention with a token-wise feed-forward
map. It has slightly more parameters; it is not an exactly parameter-matched
ablation. Both are trained for 80 epochs with AdamW, independently for seeds
0,1,2. The transformer is local: its total cost scales linearly with mesh cells,
although its constant inference cost can still be too high.

Local attention is a representation choice, not a novelty claim. Related
foundations include [Set Transformer](https://arxiv.org/abs/1810.00825), which
addresses unordered inputs, and [Galerkin Transformer](https://arxiv.org/abs/2105.14995),
which studies attention for PDE operator learning. Neither result establishes
that this limiter will improve. Learned reconstruction already has precedent
in [WENO3-NN](https://doi.org/10.1016/j.jcp.2021.110920); this experiment is not
a reproduction of its higher-order finite-difference scheme.

## Frozen evaluation

All six checkpoint hashes are written before evaluation begins. There are 99
runs: nine methods on eleven cases. Methods are the physical guard, the earlier
MRS P1 specialization, fixed 1.5 sharpening through the same gate and guard,
three attention seeds and three pooling seeds. The classical controls are
explicit, untuned specializations rather than claims of best possible classical
performance.

Fresh cases are smooth periodic advection at n=10,20,40; translating diamonds
and rings at n=12,20 on both mesh types; and a shifted slotted disk rotating for
0.35 revolutions at n=12,20 on both mesh types. Delaunay evaluation uses a new
seed and stronger jitter. Rotation is an intentional distribution shift because
training uses constant translation. Every method starts from the same bounded
L2 projection. Errors are against analytic fields at two composite quadrature
levels. Conservation residual subtracts independently integrated boundary flux.
Method order is shuffled within each case; timing includes controller setup and
inference, but excludes error quadrature and file output.

Acceptance requires at least 10% mean paired sharp-case L1 improvement over
the guard, no sharp case more than 5% worse, a positive mean gain over the best
of the three classical controls per case, smooth final convergence order at
least 1.8, average paired runtime at most 1.25 times the guard, bound violation
at most 1e-12, conservation residual at most 1e-10, and quadrature refinement
change at most 1%. All three attention seeds must pass; incomplete or failed
evidence cannot be accepted. These gates are applied without tuning on final
cases. Runtime measurements are from one CPU execution, not replicated
hardware-independent performance estimates.

## Reproduce

```sh
.venv/bin/python -m pytest -q
.venv/bin/python -m scripts.train_stencil_transformer --out runs/stencil-transformer-reproduction
.venv/bin/python -m scripts.audit_stencil_data --run runs/stencil-transformer-reproduction
```

The output directory must be new. The run stores source/configuration hashes,
environment versions, both datasets, oracle diagnostics, the behavior model,
all six selected checkpoints, training statistics, final nodal fields and their
hashes, raw metrics and the acceptance decision. Reproduction can vary across
hardware or library versions even with fixed seeds and deterministic PyTorch
settings. The exact executed source is preserved separately from any later
consolidated code improvements.

## Result

The [complete assessment](transformer-results.md) records 99 attempts, 97
completed solves and two 120-second timeouts. The completed attention seed has
5.11% higher mean sharp-case L1 error than the guard. No partial-seed mean is
reported for either timed-out seed. Smooth errors also expose repeated-sharpening
failures. No learned checkpoint is promoted. The subsequent
[time-relaxed design](transport-transformer-v2.md) changes the action and data
distribution in response; it is a separate experiment.
