# Transformer reconstruction: measured results

All seeds are reported. Positive sharp-case improvement means lower L1 error than guard-only.
The two designs use different final parameters; their absolute errors are not paired comparisons.

**The positive accuracy result is the deterministic control:** mean sharp-case L1 error falls by 9.41%, with gains of 5.79–16.08% on all eight sharp cases. It matches the tested smooth accuracy. The learned models do not improve on that control consistently.


## Instantaneous reconstruction

99 runs attempted; 2 failed. Adopt attention: **False**.

| Model | Mean sharp L1 improvement | Worst sharp L1 ratio | Final smooth order | Mean runtime / guard | Failed gates |
|---|---:|---:|---:|---:|---|
| attention-0 | -5.11% | 1.152 | 1.898 | 19.25 | improvement, best_classical, regression, runtime |
| attention-1 | — | — | — | — | A model case or the paired guard control failed. No partial mean is reported. |
| attention-2 | — | — | — | — | A model case or the paired guard control failed. No partial mean is reported. |
| pool-0 | -0.78% | 1.162 | 1.298 | 12.03 | improvement, best_classical, regression, smooth, runtime |
| pool-1 | +5.12% | 1.067 | -0.092 | 11.62 | improvement, best_classical, regression, smooth, runtime |
| pool-2 | -23.47% | 1.358 | 1.898 | 11.68 | improvement, best_classical, regression, runtime |

Finest sharp cases; learned columns average all three seeds.

| Case | Guard L1 | Fixed sharpening L1 | Attention mean L1 | Pooling mean L1 |
|---|---:|---:|---:|---:|
| diamond-ring, structured, n=20 | 0.036606 | 0.037050 | 0.041913 | 0.041766 |
| diamond-ring, delaunay, n=20 | 0.036166 | 0.036642 | 0.041305 | 0.041000 |
| rotation-slot, structured, n=20 | 0.031077 | 0.024049 | 0.035350 | 0.030709 |
| rotation-slot, delaunay, n=20 | 0.030949 | 0.024883 | failed seed | 0.030490 |

Across successful runs: maximum bound violation 1.110e-16; maximum boundary-accounted mass residual 7.394e-15; maximum L1 quadrature refinement change 0.1798%.

At the finest smooth mesh n=40, attention L2 / guard L2 ranges from 0.929 to 22.870. A convergence-rate gate alone does not bound absolute error.

## Time-relaxed reconstruction

99 runs attempted; 0 failed. Adopt attention: **False**.

| Model | Mean sharp L1 improvement | Worst sharp L1 ratio | Final smooth order | Mean runtime / guard | Failed gates |
|---|---:|---:|---:|---:|---|
| attention-0 | -0.09% | 1.108 | 1.992 | 9.56 | improvement, best_classical, regression, runtime |
| attention-1 | -24.81% | 1.449 | 1.992 | 9.86 | improvement, best_classical, regression, runtime |
| attention-2 | -15.91% | 1.333 | 1.992 | 10.04 | improvement, best_classical, regression, runtime |
| pool-0 | -1.60% | 1.033 | 1.992 | 8.71 | improvement, best_classical, runtime |
| pool-1 | +1.69% | 1.001 | 1.992 | 8.78 | improvement, best_classical, runtime |
| pool-2 | +2.35% | 1.038 | 1.992 | 9.36 | improvement, best_classical, runtime |

Finest sharp cases; learned columns average all three seeds.

| Case | Guard L1 | Fixed sharpening L1 | Attention mean L1 | Pooling mean L1 |
|---|---:|---:|---:|---:|
| diamond-ring, structured, n=24 | 0.032121 | 0.030260 | 0.037912 | 0.032887 |
| diamond-ring, delaunay, n=24 | 0.032118 | 0.029926 | 0.037640 | 0.032349 |
| rotation-slot, structured, n=24 | 0.028567 | 0.024332 | 0.035665 | 0.027881 |
| rotation-slot, delaunay, n=24 | 0.029804 | 0.025010 | 0.036114 | 0.029161 |

Across successful runs: maximum bound violation 5.551e-17; maximum boundary-accounted mass residual 1.108e-14; maximum L1 quadrature refinement change 0.0485%.

At the finest smooth mesh n=48, attention L2 / guard L2 ranges from 1.000 to 1.000. A convergence-rate gate alone does not bound absolute error.

## Decision and limits

Neither checkpoint family is promoted unless every attention seed passes every gate. Physical bounds do not establish low error, entropy stability or long-time robustness. The timestep correction changes the action, sensor and data distribution together, so the second design does not isolate any one of those factors.

Timings come from a shared host with some overlapping experiment work. They include inference and geometry setup, and exclude reference-error quadrature. Precise deployment cost needs isolated repeated measurements.

The first aborted data-generation attempt was excluded before evaluation. Both completed runs retain source/configuration snapshots, datasets, model and field hashes. Final cases were not used to select checkpoints. The second design uses known benchmark families with new parameters and meshes; it is not an external blind test.

## Optimized inference check

These subsequent measurements use the same checkpoints and numerical decisions. Unused features and candidates are skipped. Each case/method has three repeats; ratios below divide method median time by paired guard median time.

| Case | Guard median (s) | Attention seed 0 median (s) | Fixed reconstruction median (s) | Attention / guard | Fixed / guard |
|---|---:|---:|---:|---:|---:|
| diamond-ring, structured, n=24 | 0.421 | 7.640 | 1.801 | 18.14 | 4.28 |
| rotation-slot, delaunay, n=24 | 12.650 | 79.467 | 17.041 | 6.28 | 1.35 |
| smooth, structured, n=48 | 3.880 | 6.095 | 6.542 | 1.57 | 1.69 |

The maximum nodal difference from the saved frozen fields is 5.773e-15. This checks numerical equivalence on the three selected cases; it is not a new accuracy evaluation or a full runtime acceptance test. The host still shows timing variation, so these small samples do not establish deployment-wide performance.
