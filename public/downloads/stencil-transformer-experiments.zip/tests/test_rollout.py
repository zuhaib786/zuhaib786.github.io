import numpy as np
import pytest

from tci.guarded import GuardedSlopeLimiter, bound_theta, scale_slopes, invariant_features
from tci.mesh import rectangular_mesh, perturbed_delaunay_mesh
from tci.quadrature import TriangleQuadrature
from tci.rollout import BatchedGuardedOperator, MRSSlopeProposal
from tci.solvers.dg2d import AdvectionDG2D


@pytest.mark.parametrize("subdivisions", [0, 1, 2])
def test_quadrature_integrates_actual_polynomial_reference(subdivisions):
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2))
    q = TriangleQuadrature(solver.mesh, order=4, subdivisions=subdivisions)
    error = q.errors(np.zeros((3, solver.K)), lambda x, y: x*x)
    assert error["l1"] == pytest.approx(1/3, abs=1e-14)
    assert error["l2"] == pytest.approx(np.sqrt(1/5), abs=1e-14)
    assert q.weights.sum() == pytest.approx(1)
    linear = lambda x, y: 1+2*x-3*y
    np.testing.assert_allclose(q.project(linear), solver.project(linear), atol=5e-14)


def test_moment_cost_agrees_with_direct_quadrature_for_many_candidates():
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2))
    q = TriangleQuadrature(solver.mesh)
    reference = lambda x, y: np.sin(x+2*y)
    states = np.random.default_rng(20).uniform(size=(3, solver.K, 4))
    costs = q.squared_error_from_moments(states, q.reference_moments(reference))
    for b in range(4):
        assert solver.mesh.areas@costs[:, b] == pytest.approx(q.errors(states[:, :, b], reference)["l2"]**2)


def test_batched_rollout_matches_production_rk_and_guard():
    solver = AdvectionDG2D(rectangular_mesh(nx=3, ny=3), velocity=(.6, -.2), periodic=(True, True))
    operator = BatchedGuardedOperator(solver)
    rng = np.random.default_rng(22)
    u = rng.uniform(.1, .9, size=(3, solver.K))
    np.testing.assert_allclose(operator.rhs(u), solver.rhs(u), atol=1e-13)
    dt = solver.stable_dt(.15)
    expected, _ = solver.solve_guarded(u, 3*dt, GuardedSlopeLimiter(0, 1))
    batch = np.stack([u, .25+.5*u], axis=-1)
    for _ in range(3):
        batch = operator.step(batch, dt)
    np.testing.assert_allclose(batch[..., 0], expected, atol=1e-14)
    np.testing.assert_allclose(batch[..., 1], .25+.5*expected, atol=1e-14)


def test_oracle_noop_cost_and_constant_states():
    solver = AdvectionDG2D(rectangular_mesh(nx=2, ny=2), periodic=(True, True))
    op = BatchedGuardedOperator(solver)
    u = np.full((3, solver.K), .5)
    _, costs, baseline = op.action_costs(u, solver.stable_dt(.15),
                                        TriangleQuadrature(solver.mesh), lambda x, y: .5, horizon=2)
    assert abs(baseline) < 1e-14
    np.testing.assert_allclose(costs, baseline, atol=1e-14)
    with pytest.raises(ValueError):
        BatchedGuardedOperator(AdvectionDG2D(solver.mesh))


def test_oracle_intervention_cost_matches_independent_full_solver_run():
    solver = AdvectionDG2D(rectangular_mesh(nx=3, ny=3), periodic=(True, True))
    op = BatchedGuardedOperator(solver)
    candidate = np.random.default_rng(72).uniform(.2, .8, (3, solver.K))
    q = TriangleQuadrature(solver.mesh)
    reference = lambda x, y: .5+.1*np.cos(2*np.pi*x)
    dt = solver.stable_dt(.15)
    _, costs, _ = op.action_costs(candidate, dt, q, reference, horizon=2)
    cell = 5
    theta = bound_theta(candidate, 0, 1)
    jump = min(invariant_features(solver, candidate, 0, 1)[cell, 4], 1)
    theta[cell] = min(theta[cell], 1-jump**2*.5)
    initial = scale_slopes(candidate, theta)
    final, _ = solver.solve_guarded(initial, 2*dt, GuardedSlopeLimiter(0, 1))
    assert costs[cell, 2] == pytest.approx(q.errors(final, reference)['l2']**2, abs=1e-14)


@pytest.mark.parametrize("rotating", [False, True])
def test_boundary_flux_matches_rhs_integral_and_completed_mass_balance(rotating):
    mesh = perturbed_delaunay_mesh(nx=4, ny=4, seed=31)
    velocity = (lambda x, y, t: np.stack([.5-y, x-.5], axis=-1)) if rotating else (.8, -.3)
    solver = AdvectionDG2D(mesh, velocity=velocity, boundary_func=lambda x, y, t: .2)
    u = np.random.default_rng(10).uniform(.1, .9, size=(3, solver.K))
    assert solver.boundary_mass_rate(u) == pytest.approx(solver.integral(solver.rhs(u)), abs=1e-13)
    controller = GuardedSlopeLimiter(0, 1)
    final, _ = solver.solve_guarded(u, .08, controller)
    residual = solver.integral(final)-solver.integral(u)-controller.boundary_transport
    assert abs(residual) < 1e-13


def test_mrs_constant_is_unchanged_and_means_are_preserved():
    solver = AdvectionDG2D(rectangular_mesh(nx=3, ny=3), periodic=(True, True))
    proposal = MRSSlopeProposal(1)
    u = np.full((3, solver.K), .4)
    np.testing.assert_array_equal(proposal(solver, u), np.ones(solver.K))
    u[:, 2] += [-.4, 0, .4]
    theta = proposal(solver, u)
    assert theta[2] < 1
    guard = GuardedSlopeLimiter(0, 1, proposal)
    limited, _ = guard.apply(solver, u)
    np.testing.assert_allclose(limited.mean(axis=0), u.mean(axis=0))


def test_incomplete_evidence_cannot_be_accepted(tmp_path):
    import json
    from pathlib import Path
    from scripts.train_rollout_limiter import summarize

    config = json.loads(Path('configs/rollout-limiter-v1.json').read_text())
    summary = summarize(tmp_path, config, [])
    assert summary['complete'] is False
    assert summary['adopt'] is False
    assert len(summary['seeds']) == 5
    assert all(not seed['accepted'] for seed in summary['seeds'])
