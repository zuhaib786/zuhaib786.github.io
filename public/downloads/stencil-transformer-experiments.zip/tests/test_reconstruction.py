import json
from pathlib import Path

import numpy as np
import pytest
import torch

from tci.guarded import GuardedSlopeLimiter
from tci.mesh import rectangular_mesh, perturbed_delaunay_mesh, TriangleMesh
from tci.quadrature import TriangleQuadrature
from tci.reconstruction import ReconstructionStencil, GuardedReconstructionLimiter, reconstruction_costs, EXPERTS
from tci.rollout import BatchedGuardedOperator
from tci.solvers.dg2d import AdvectionDG2D
from tci.stencil_attention import StencilNetwork, StencilPolicy


def solver_fixture(periodic=True):
    return AdvectionDG2D(perturbed_delaunay_mesh(nx=3, ny=3, seed=81),
                         velocity=(.6,-.3), periodic=(periodic,periodic))


def test_all_experts_preserve_means_bounds_and_constants():
    solver = solver_fixture()
    stencil = ReconstructionStencil(solver)
    u = np.random.default_rng(4).uniform(0, 1, (3,solver.K))
    candidates = stencil.candidates(u)
    for j in range(len(EXPERTS)):
        np.testing.assert_allclose(candidates[..., j].mean(axis=0), u.mean(axis=0), atol=3e-16)
    assert candidates.min() >= -1e-15 and candidates.max() <= 1+1e-15
    constant = np.full_like(u,.4)
    np.testing.assert_allclose(stencil.candidates(constant), .4, atol=1e-16)


def test_affine_smooth_field_unchanged_including_boundary_stencils():
    solver = solver_fixture(False)
    u = solver.project(lambda x,y:.25+.2*x+.1*y)
    candidates = ReconstructionStencil(solver).candidates(u)
    for j in range(len(EXPERTS)):
        np.testing.assert_allclose(candidates[..., j],u,atol=2e-16)


def test_geometry_and_actions_invariant_to_cyclic_vertex_numbering():
    solver = solver_fixture()
    mesh = TriangleMesh(solver.mesh.points, np.roll(solver.mesh.cells,1,axis=1))
    rotated = AdvectionDG2D(mesh,velocity=solver.velocity,periodic=solver.periodic)
    u = np.random.default_rng(5).uniform(.1,.9,(3,solver.K))
    a, b = ReconstructionStencil(solver), ReconstructionStencil(rotated)
    np.testing.assert_allclose(a.encode(u)[0],b.encode(np.roll(u,1,axis=0))[0],atol=1e-7)
    np.testing.assert_allclose(np.roll(a.candidates(u),1,axis=0),b.candidates(np.roll(u,1,axis=0)),atol=1e-14)


@pytest.mark.parametrize('architecture',['attention','pool'])
def test_network_neighbor_permutation_and_padding_invariance(architecture):
    torch.manual_seed(17)
    model = StencilNetwork(architecture).eval()
    torch.nn.init.normal_(model.readout[-1].weight)  # avoid vacuous zero-output test
    x = torch.randn(2,10,18)
    mask = torch.ones(2,10,dtype=torch.bool);mask[:,8:]=False
    permutation = torch.tensor([0,4,2,9,3,1,6,8,5,7])
    with torch.no_grad():
        expected = model(x,mask)
        torch.testing.assert_close(model(x[:,permutation],mask[:,permutation]),expected,atol=2e-6,rtol=2e-6)
        x[:,8:] = 100
        torch.testing.assert_close(model(x,mask),expected,atol=2e-6,rtol=2e-6)


@pytest.mark.parametrize('stage',[1,2,3])
@pytest.mark.parametrize('transport',[False,True])
def test_stage_oracle_cost_matches_actual_full_rk_solver(stage,transport):
    solver = solver_fixture()
    op = BatchedGuardedOperator(solver)
    u = np.random.default_rng(29).uniform(.2,.8,(3,solver.K))
    dt = solver.stable_dt(.15)
    if transport:
        from tci.transport_reconstruction import TransportStencil
        stencil=TransportStencil(solver,dt)
    else:
        stencil=ReconstructionStencil(solver)
    candidate = u+dt*solver.rhs(u)
    if stage>1:
        v1 = op.guard(candidate)
        candidate = .75*u+.25*(v1+dt*solver.rhs(v1))
    if stage>2:
        v2 = op.guard(candidate)
        candidate = u/3+2/3*(v2+dt*solver.rhs(v2))
    q = TriangleQuadrature(solver.mesh)
    reference = lambda x,y:.5+.1*np.cos(2*np.pi*x)
    costs,_ = reconstruction_costs(op,stencil,u,candidate,stage,dt,q,reference,horizon=3)
    class OneIntervention(GuardedSlopeLimiter):
        def __init__(self):
            super().__init__(0,1);self.calls=0
        def apply(self,sol,value,*,initial=False):
            result,stats = super().apply(sol,value,initial=initial)
            if not initial:
                self.calls+=1
                if self.calls==stage:
                    result[:,4]=stencil.candidates(value)[:,4,3]
            return result,stats
    result,_ = solver.solve_guarded(u,3*dt,OneIntervention())
    assert costs[4,3] == pytest.approx(q.errors(result,reference)['l2']**2,abs=2e-14)


def test_reconstruction_fallback_and_full_mass_balance():
    solver = solver_fixture()
    u = np.random.default_rng(26).uniform(.1,.9,(3,solver.K))
    controller = GuardedReconstructionLimiter(lambda s,u:np.full(s.solver.K,np.nan))
    expected,_ = GuardedSlopeLimiter(0,1).apply(solver,u)
    actual,_ = controller.apply(solver,u)
    np.testing.assert_array_equal(expected,actual)
    assert controller.invalid_predictions==solver.K
    controller = GuardedReconstructionLimiter(lambda s,u:np.full(s.solver.K,3))
    actual,_ = solver.solve_guarded(u,.04,controller)
    assert abs(solver.integral(actual)-solver.integral(u)-controller.boundary_transport)<1e-13
    assert actual.min()>=-1e-12 and actual.max()<=1+1e-12


def test_checkpoint_reload_and_noop_ties(tmp_path):
    model = StencilNetwork()
    path = tmp_path/'model.pt'
    torch.save(dict(schema=1,experts=list(EXPERTS),architecture='attention',width=24,
                    state=model.state_dict(),center=[0.]*18,scale=[1.]*18,margin=.02),path)
    solver = solver_fixture()
    assert np.all(StencilPolicy(path)(ReconstructionStencil(solver),np.full((3,solver.K),.4))==0)


def test_missing_evaluations_never_accepted(tmp_path):
    from scripts.train_stencil_transformer import summarize
    config = json.loads(Path('configs/stencil-transformer-v1.json').read_text())
    assert summarize(tmp_path,config,[])['adopt'] is False


def test_each_training_family_crosses_both_mesh_types_and_resolutions():
    from scripts.train_stencil_transformer import training_case
    config = json.loads(Path('configs/stencil-transformer-v1.json').read_text())
    observed = {family:set() for family in range(6)}
    for group in range(config['train_trajectories']):
        solver,_ = training_case(group,config)
        lengths = solver.mesh.edge_lengths
        structured = len(np.unique(np.round(lengths.ravel(),10)))==2
        observed[group%6].add((solver.K,structured))
    assert all(len(combinations)==4 for combinations in observed.values())


def test_transport_reconstruction_vanishes_linearly_with_time_step():
    from tci.transport_reconstruction import TransportStencil
    solver=solver_fixture()
    u=np.random.default_rng(41).uniform(.1,.9,(3,solver.K))
    dt=solver.stable_dt(.15)
    a=TransportStencil(solver,dt).candidates(u)
    b=TransportStencil(solver,dt/2).candidates(u)
    zero=TransportStencil(solver,0).candidates(u)
    np.testing.assert_allclose(b-zero,.5*(a-zero),atol=3e-16)
    for j in range(len(EXPERTS)):
        np.testing.assert_allclose(a[...,j].mean(axis=0),u.mean(axis=0),atol=3e-16)
    assert a.min()>=0 and a.max()<=1


def test_transport_policy_receives_actual_shortened_final_step():
    from tci.transport_reconstruction import GuardedTransportLimiter
    solver=solver_fixture()
    dt=solver.stable_dt(.15);seen=[]
    def policy(stencil,u):
        seen.append((stencil.dt,stencil.time))
        return np.full(solver.K,2)
    u=np.random.default_rng(91).uniform(.3,.7,(3,solver.K))
    controller=GuardedTransportLimiter(policy)
    actual,_=solver.solve_guarded(u,1.5*dt,controller)
    np.testing.assert_allclose(np.array(seen)[:,0],[dt]*3+[dt/2]*3,atol=1e-16)
    np.testing.assert_allclose(np.array(seen)[:,1],[dt,dt/2,dt,1.5*dt,1.25*dt,1.5*dt],atol=1e-16)
    assert abs(solver.integral(actual)-solver.integral(u))<1e-13


def test_nonfinite_network_scores_reach_guard_fallback(tmp_path):
    model=StencilNetwork()
    with torch.no_grad():model.readout[-1].bias.fill_(torch.nan)
    path=tmp_path/'invalid.pt'
    torch.save(dict(schema=1,experts=list(EXPERTS),architecture='attention',width=24,state=model.state_dict(),
                    center=[0.]*18,scale=[1.]*18,margin=.02),path)
    solver=solver_fixture();u=np.full((3,solver.K),.4)
    controller=GuardedReconstructionLimiter(StencilPolicy(path))
    result,_=controller.apply(solver,u)
    assert controller.invalid_predictions==solver.K
    np.testing.assert_array_equal(result,u)


def test_retry_updates_transport_context_before_policy_is_called():
    from tci.guarded import InadmissibleMean
    from tci.transport_reconstruction import GuardedTransportLimiter
    solver=solver_fixture();dt=solver.stable_dt(.15);seen=[]
    def policy(stencil,u):
        seen.append(stencil.dt)
        return np.zeros(solver.K)
    class RetryOnce(GuardedTransportLimiter):
        rejected=False
        def apply(self,s,u,*,initial=False):
            if not initial and not self.rejected:
                self.rejected=True
                raise InadmissibleMean('force one rejected attempt to test context')
            return super().apply(s,u,initial=initial)
    controller=RetryOnce(policy)
    solver.solve_guarded(np.random.default_rng(2).uniform(.1,.9,(3,solver.K)),dt,controller)
    assert controller.rejected_steps==1
    np.testing.assert_allclose(seen,[dt/2]*6,atol=1e-16)


def test_fast_jump_matches_full_feature_and_inactive_policy_is_skipped():
    from tci.reconstruction import maximum_face_jump
    from tci.guarded import invariant_features
    from tci.transport_reconstruction import GuardedTransportLimiter
    solver=solver_fixture()
    u=np.random.default_rng(38).uniform(0,1,(3,solver.K))
    np.testing.assert_array_equal(maximum_face_jump(solver,u),invariant_features(solver,u,0,1)[:,4])
    def forbidden(stencil,u):
        raise AssertionError('no neural inference needed on inactive field')
    result,_=solver.solve_guarded(np.full_like(u,.4),.02,GuardedTransportLimiter(forbidden))
    np.testing.assert_allclose(result,.4,atol=1e-15)


def test_specialized_fixed_expert_matches_general_controller():
    from tci.transport_reconstruction import GuardedTransportLimiter,FixedTransportSharpenLimiter
    solver=solver_fixture()
    u=np.random.default_rng(57).uniform(.1,.9,(3,solver.K))
    general=GuardedTransportLimiter(lambda s,u:np.full(s.solver.K,2))
    expected,_=solver.solve_guarded(u,.025,general)
    actual,_=solver.solve_guarded(u,.025,FixedTransportSharpenLimiter())
    np.testing.assert_allclose(actual,expected,atol=1e-14,rtol=1e-14)


def test_fully_attempted_failed_suite_reports_failures_without_partial_averages(tmp_path):
    from scripts.train_stencil_transformer import summarize
    config=json.loads(Path('configs/stencil-transformer-v1.json').read_text())
    cases=[('smooth','structured',n) for n in config['smooth_resolutions']]
    cases += [(p,m,n) for p in ['diamond-ring','rotation-slot'] for m in ['structured','delaunay'] for n in config['evaluation_resolutions']]
    names=['guard','mrs','fixed-sharpen']+[f'{a}-{s}' for a in ['attention','pool'] for s in config['initialization_seeds']]
    rows=[dict(problem=p,mesh=m,n=n,method=name,status='failed') for p,m,n in cases for name in names]
    summary=summarize(tmp_path,config,rows)
    assert summary['complete'] and not summary['adopt'] and summary['failures']==99
    assert all(not r['accepted'] and 'sharp_l1_improvement' not in r for r in summary['models'])
