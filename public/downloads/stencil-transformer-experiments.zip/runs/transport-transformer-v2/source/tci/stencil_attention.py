"""Small set transformer and matched pooling ablation for reconstruction.

No global cell IDs or sequence-position embeddings. Attention is local to at
most ten cells, so total inference cost is linear in the mesh cell count.
PyTorch is an optional dependency, imported only by this ML module.
"""

import numpy as np
import torch
from torch import nn

from tci.reconstruction import EXPERTS, TOKEN_DIM


class StencilNetwork(nn.Module):
    def __init__(self, architecture='attention', width=24, heads=3, input_dim=TOKEN_DIM):
        super().__init__()
        if architecture not in ('attention', 'pool') or width % heads:
            raise ValueError('invalid architecture or head dimensions')
        self.architecture, self.width, self.heads = architecture, width, heads
        self.embedding = nn.Linear(input_dim, width)
        self.norm1 = nn.LayerNorm(width)
        self.mix = nn.Linear(width, 3*width)
        self.project = nn.Linear(width if architecture == 'attention' else 3*width, width)
        self.norm2 = nn.LayerNorm(width)
        self.ff = nn.Sequential(nn.Linear(width, 2*width), nn.GELU(), nn.Linear(2*width, width))
        self.readout = nn.Sequential(nn.Linear(2*width, width), nn.GELU(), nn.Linear(width, len(EXPERTS)-1))
        nn.init.zeros_(self.readout[-1].weight)
        nn.init.zeros_(self.readout[-1].bias)

    def forward(self, x, mask):
        z = self.embedding(x)
        v = self.mix(self.norm1(z))
        if self.architecture == 'attention':
            b, n, _ = v.shape
            q, k, value = v.reshape(b, n, 3, self.heads, self.width//self.heads).permute(2, 0, 3, 1, 4)
            scores = (q@k.transpose(-1, -2))/(self.width//self.heads)**.5
            scores = scores.masked_fill(~mask[:, None, None, :], -torch.inf)
            v = (scores.softmax(dim=-1)@value).transpose(1, 2).reshape(b, n, self.width)
        else:
            # Same tokens and readout, no token-token attention. Slightly more
            # parameters than attention because the mix projection is wider.
            v = torch.nn.functional.gelu(v)
        z = z+self.project(v)
        z = z+self.ff(self.norm2(z))
        pooled = (z*mask[..., None]).sum(dim=1)/mask.sum(dim=1, keepdim=True)
        return self.readout(torch.cat([z[:, 0], pooled], dim=-1))


class StencilPolicy:
    def __init__(self, path):
        checkpoint = torch.load(path, map_location='cpu', weights_only=True)
        if checkpoint['schema'] != 1 or checkpoint['experts'] != list(EXPERTS):
            raise ValueError('unsupported stencil checkpoint')
        self.model = StencilNetwork(checkpoint['architecture'], checkpoint['width'],
                                    input_dim=checkpoint.get('input_dim', TOKEN_DIM))
        self.model.load_state_dict(checkpoint['state'])
        self.model.eval()
        self.center = np.asarray(checkpoint['center'], dtype=np.float32)
        self.scale = np.asarray(checkpoint['scale'], dtype=np.float32)
        self.margin = checkpoint['margin']

    def __call__(self, stencil, u):
        x, mask = stencil.encode(u)
        active = stencil.active(u) if hasattr(stencil, 'active') else np.ones(len(x), dtype=bool)
        result = np.zeros(len(x))
        if not active.any():
            return result
        with torch.inference_mode():
            scores = self.model(torch.from_numpy((x[active]-self.center)/self.scale), torch.from_numpy(mask[active])).numpy()
        choice = (scores.argmax(axis=1)+1).astype(float)
        choice[scores.max(axis=1) <= self.margin] = 0
        choice[~np.isfinite(scores).all(axis=1)] = np.nan
        result[active] = choice
        return result
