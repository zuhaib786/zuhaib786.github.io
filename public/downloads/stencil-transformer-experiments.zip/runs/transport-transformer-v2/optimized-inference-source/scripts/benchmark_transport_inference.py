"""Check optimized inference against saved fields, then time fixed paired cases.

Run after other experiments finish. These timings supplement, rather than
replace, the frozen experiment. No model, sensor, action or threshold is tuned.
"""

import json
import time
from pathlib import Path

import numpy as np
import torch

from scripts.train_stencil_transformer import write_json,sha
from scripts.train_transport_transformer import evaluation_cases
from tci.guarded import GuardedSlopeLimiter
from tci.stencil_attention import StencilPolicy
from tci.transport_reconstruction import GuardedTransportLimiter,FixedTransportSharpenLimiter


def main():
    root=Path('runs/transport-transformer-v2')
    config=json.loads((root/'manifest.json').read_text())['config']
    rows=json.loads((root/'evaluation.json').read_text())
    if len(rows)!=99:
        raise SystemExit('Finish the frozen evaluation first.')
    torch.set_num_threads(1)
    policy=StencilPolicy(root/'models/attention-0.pt')
    records=[]
    for problem,mesh,n,solver,exact,final_time in evaluation_cases(config):
        if not ((problem=='smooth' and n==max(config['smooth_resolutions'])) or
                (problem=='diamond-ring' and mesh=='structured' and n==max(config['evaluation_resolutions'])) or
                (problem=='rotation-slot' and mesh=='delaunay' and n==max(config['evaluation_resolutions']))):
            continue
        paired={r['method']:r for r in rows if (r['problem'],r['mesh'],r['n'])==(problem,mesh,n)}
        for repeat in range(3):
            order=['guard','attention-0','fixed-sharpen'] if repeat%2==0 else ['fixed-sharpen','attention-0','guard']
            for method in order:
                row=paired[method]
                if row['status']!='ok':
                    raise SystemExit(f'{method} failed; cannot claim equivalence to an absent field.')
                with np.load(root/row['field']) as data:
                    initial,saved=data['initial'],data['result']
                controller=(GuardedSlopeLimiter(0,1) if method=='guard' else
                            FixedTransportSharpenLimiter() if method=='fixed-sharpen' else GuardedTransportLimiter(policy))
                start=time.perf_counter()
                result,_=solver.solve_guarded(initial,final_time,controller,cfl=config['cfl'],max_seconds=120)
                elapsed=time.perf_counter()-start
                difference=float(np.max(np.abs(result-saved)))
                np.testing.assert_allclose(result,saved,atol=1e-12,rtol=1e-12)
                record=dict(problem=problem,mesh=mesh,n=n,method=method,repeat=repeat,
                            runtime_s=elapsed,max_nodal_difference=difference)
                records.append(record)
                print(json.dumps(record),flush=True)
    source=root/'optimized-inference-source';source.mkdir(exist_ok=True)
    paths=[Path(__file__).resolve().relative_to(Path.cwd()),Path('scripts/train_transport_transformer.py'),
           Path('scripts/train_stencil_transformer.py'),*Path('tci').rglob('*.py')]
    hashes={}
    for path in paths:
        dest=source/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(path.read_bytes())
        hashes[str(path)]=sha(path)
    write_json(root/'optimized-inference.json',dict(records=records,source_sha256=hashes,
        note='Fixed seed 0, three predetermined cases, three repetitions. Fields checked against frozen evaluation.'))


if __name__=='__main__':main()
