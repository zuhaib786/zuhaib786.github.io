"""Time-relaxed reconstruction with longer behavior trajectories.

This is a second experimental design, following the rejected instantaneous
reconstruction. Final shape families are known; their parameters/meshes are
held out anew. No claim of an external, untouched benchmark is made.
"""

import argparse
import json
import platform
import subprocess
from pathlib import Path

import numpy as np
import torch

from scripts.train_stencil_transformer import training_case, fit, evaluate, summarize, write_json, sha
from tci.evaluate2d import rotational_velocity
from tci.guarded import GuardedSlopeLimiter
from tci.mesh import rectangular_mesh,perturbed_delaunay_mesh
from tci.quadrature import TriangleQuadrature
from tci.reconstruction import reconstruction_costs
from tci.rollout import BatchedGuardedOperator
from tci.solvers.dg2d import AdvectionDG2D
from tci.stencil_attention import StencilPolicy
from tci.transport_reconstruction import TransportStencil, GuardedTransportLimiter


def collect(out,config,policy=None):
    out.mkdir()
    data = {k:[] for k in ['x','mask','costs','groups','areas','action_scale']}
    records=[]
    count=config['train_trajectories']+(config['validation_trajectories'] if policy is None else 0)
    for group in range(count):
        solver,reference=training_case(group,config)
        q=TriangleQuadrature(solver.mesh,6,2)
        controller=GuardedSlopeLimiter(0,1) if policy is None else GuardedTransportLimiter(policy)
        u,_=controller.apply(solver,q.project(lambda x,y:reference(x,y,0)),initial=True)
        op=BatchedGuardedOperator(solver)
        dt=solver.stable_dt(config['cfl']);t=0.
        stencil=TransportStencil(solver,dt)
        for snapshot,target_time in enumerate(config['snapshot_times']):
            if target_time>t:
                u,_=solver.solve_guarded(u,target_time-t,controller,cfl=config['cfl'])
                t=target_time
            stage=snapshot%3+1
            controller.stage_dt,controller.stage_time=dt,t+dt
            candidate=u+dt*solver.rhs(u)
            if stage>1:
                v1,_=controller.apply(solver,candidate)
                candidate=.75*u+.25*(v1+dt*solver.rhs(v1))
            if stage>2:
                controller.stage_time=t+dt/2
                v2,_=controller.apply(solver,candidate)
                candidate=u/3+2/3*(v2+dt*solver.rhs(v2))
            stencil.time=t+dt/2 if stage==2 else t+dt
            future=t+config['horizon_steps']*dt
            costs,record=reconstruction_costs(op,stencil,u,candidate,stage,dt,q,
                lambda x,y:reference(x,y,future),config['horizon_steps'])
            x,mask=stencil.encode(candidate)
            for k,value in dict(x=x,mask=mask,costs=costs,groups=np.full(solver.K,group),
                                areas=solver.mesh.areas,action_scale=stencil.action_scale(candidate)).items():
                data[k].append(value)
            records.append(dict(group=group,time=t,stage=stage,**record))
        print(f'{out.name} {group+1}/{count}',flush=True)
    data={k:np.concatenate(v) for k,v in data.items()}
    np.savez_compressed(out/'data.npz',**data)
    write_json(out/'oracle.json',records)
    return data


def evaluation_cases(config):
    for n in config['smooth_resolutions']:
        solver=AdvectionDG2D(rectangular_mesh(nx=n,ny=n),velocity=(-.58,-.39),periodic=(True,True))
        def smooth(x,y,t):
            return .5+.26*np.cos(2*np.pi*(x+.58*t+.13))*np.sin(2*np.pi*(y+.39*t+.07))
        yield 'smooth','structured',n,solver,smooth,.14
    for n in config['evaluation_resolutions']:
        for kind in ['structured','delaunay']:
            mesh=(rectangular_mesh(nx=n,ny=n) if kind=='structured' else
                  perturbed_delaunay_mesh(nx=n,ny=n,jitter=.27,seed=config['evaluation_mesh_seed']))
            solver=AdvectionDG2D(mesh,velocity=(-.58,-.39),periodic=(True,True))
            def shapes(x,y,t):
                xx,yy=(x+.58*t)%1,(y+.39*t)%1
                diamond=np.abs(xx-.67)+np.abs(yy-.31)<.16
                r=(xx-.29)**2+(yy-.69)**2
                return .75*diamond.astype(float)+.7*((r<.15**2)&(r>.08**2)).astype(float)
            yield 'diamond-ring',kind,n,solver,shapes,.27
            rotation=AdvectionDG2D(mesh,velocity=rotational_velocity,boundary_func=lambda x,y,t:np.zeros_like(x))
            def slot(x,y,t):
                a=-2*np.pi*t
                xx=.5+np.cos(a)*(x-.5)-np.sin(a)*(y-.5)
                yy=.5+np.sin(a)*(x-.5)+np.cos(a)*(y-.5)
                disk=(xx-.62)**2+(yy-.39)**2<.145**2
                cut=(np.abs(yy-.39)<.032)&(xx>.6)
                return (disk&~cut).astype(float)
            yield 'rotation-slot',kind,n,rotation,slot,.4


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path('configs/transport-transformer-v2.json'))
    parser.add_argument('--out',type=Path,default=Path('runs/transport-transformer-v2'))
    args=parser.parse_args()
    if args.out.exists():raise SystemExit('Use a new directory; evidence is immutable.')
    config=json.loads(args.config.read_text())
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    args.out.mkdir(parents=True);source=args.out/'source';source.mkdir()
    paths=[args.config,Path(__file__).resolve().relative_to(Path.cwd()),
           Path('scripts/train_stencil_transformer.py'),*Path('tci').rglob('*.py')]
    hashes={}
    for path in paths:
        dest=source/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(path.read_bytes())
        hashes[str(path)]=sha(path)
    write_json(args.out/'manifest.json',dict(config=config,source_sha256=hashes,
        base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        python=platform.python_version(),numpy=np.__version__,torch=torch.__version__))
    data=collect(args.out/'guard-data',config)
    provisional=fit(args.out/'behavior-model',data,config,['attention'],[0])
    extra=collect(args.out/'behavior-data',config,StencilPolicy(args.out/'behavior-model'/provisional[0]['checkpoint']))
    combined={k:np.concatenate([data[k],extra[k]]) for k in data}
    models=fit(args.out/'models',combined,config,['attention','pool'],config['initialization_seeds'])
    write_json(args.out/'frozen-models.json',models)
    rows=evaluate(args.out,config,models,case_factory=evaluation_cases,reconstruction_controller=GuardedTransportLimiter)
    print(json.dumps(summarize(args.out,config,rows),indent=2),flush=True)


if __name__=='__main__':main()
