"""Time-relaxed reconstruction: an experimental correction to repeated sharpening.

The update vanishes with dt at fixed mesh. Its stricter smooth-region sensor
and physical guard are deterministic. This is not an entropy stability proof.
"""

import numpy as np

from tci.guarded import GuardedSlopeLimiter, bound_theta, scale_slopes
from tci.reconstruction import ReconstructionStencil, GuardedReconstructionLimiter, maximum_face_jump


class TransportStencil(ReconstructionStencil):
    def __init__(self, solver, dt, time=0.):
        super().__init__(solver)
        self.dt, self.time = dt, time

    def rate(self):
        if not np.isfinite(self.dt) or self.dt < 0:
            raise ValueError('finite nonnegative stage dt required')
        xy = self.solver.mesh.centroids
        velocity = self.solver.velocity_values(xy[:,0],xy[:,1],self.time)
        return np.linalg.norm(velocity,axis=1)*self.dt/self.h

    def action_scale(self,u):
        jump = maximum_face_jump(self.solver,u)
        threshold = 2*self.h**1.5
        sensor = np.clip((jump-threshold)/threshold,0,1)
        return np.minimum(.25,self.rate())*sensor

    def active(self,u):
        return self.action_scale(u)>0

    def candidates(self,u):
        experts = super().candidates(u)
        alpha = self.action_scale(u)
        return experts[...,:1]+alpha[None,:,None]*(experts-experts[...,:1])

    def encode(self,u):
        x,mask = super().encode(u)
        xy = self.solver.mesh.centroids
        velocity = self.solver.velocity_values(xy[:,0],xy[:,1],self.time)
        speed = np.linalg.norm(velocity,axis=1)
        x[...,12:14] = (velocity/np.maximum(speed[:,None],1e-14))[:,None]
        x[...,14] = speed[:,None]
        extra = np.zeros(self.indices.shape+(4,),dtype=np.float32)
        extra[...,0] = self.rate()[:,None]
        extra[...,1] = self.rate()[self.safe]
        extra[...,2:4] = self.dt/self.h[:,None,None]*(velocity[self.safe]-velocity[:,None])
        extra[~mask] = 0
        return np.concatenate([x,extra],axis=-1),mask


class GuardedTransportLimiter(GuardedReconstructionLimiter):
    def apply(self,solver,u,*,initial=False):
        if not initial:
            if not hasattr(self,'stage_dt'):
                raise ValueError('stage context required; use solve_guarded or set stage_dt/time explicitly')
            if self.stencil is None or self.stencil.solver is not solver:
                self.stencil = TransportStencil(solver,self.stage_dt,self.stage_time)
            self.stencil.dt,self.stencil.time = self.stage_dt,self.stage_time
            if not self.stencil.active(u).any():
                result,stats=GuardedSlopeLimiter.apply(self,solver,u,initial=True)
                result=scale_slopes(result,bound_theta(result,0,1))
                stats.update(minimum=float(result.min()),maximum=float(result.max()),reconstruction_fraction=0.)
                return result,stats
        result,stats = super().apply(solver,u,initial=initial)
        if not initial:
            base = scale_slopes(u,bound_theta(u,0,1))
            stats['reconstruction_fraction'] = float(np.mean(np.any(np.abs(result-base)>1e-13,axis=0)))
        return result,stats


class FixedTransportSharpenLimiter(GuardedSlopeLimiter):
    """The fixed 1.5 expert, without building unused experts or ML tokens.

    Numerically equivalent to GuardedTransportLimiter selecting expert 2.
    This is a deterministic control, not a learned model.
    """

    def __init__(self):
        super().__init__(0,1)

    def apply(self,solver,u,*,initial=False):
        base,stats=super().apply(solver,u,initial=initial)
        if initial:return base,stats
        if not hasattr(self,'stage_dt'):
            raise ValueError('actual RK stage context required')
        h=np.sqrt(solver.mesh.areas)
        jump=maximum_face_jump(solver,u)
        threshold=2*h**1.5
        sensor=np.clip((jump-threshold)/threshold,0,1)
        xy=solver.mesh.centroids
        speed=np.linalg.norm(solver.velocity_values(xy[:,0],xy[:,1],self.stage_time),axis=1)
        alpha=np.minimum(.25,self.stage_dt*speed/h)*sensor
        mean=u.mean(axis=0)
        proposed=mean+1.5*(u-mean)
        proposed-=proposed.mean(axis=0)-mean
        expert=scale_slopes(proposed,bound_theta(proposed,0,1))
        result=base+alpha*(expert-base)
        result=scale_slopes(result,bound_theta(result,0,1))
        stats.update(minimum=float(result.min()),maximum=float(result.max()),
                     reconstruction_fraction=float(np.mean(np.any(np.abs(result-base)>1e-13,axis=0))))
        return result,stats
