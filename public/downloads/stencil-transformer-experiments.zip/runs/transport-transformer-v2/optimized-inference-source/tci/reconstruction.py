"""Conservative reconstruction experts and unordered geometric stencil tokens.

Experimental scalar P1 controller on affine triangles. Every expert keeps the
current mean; an independent bound guard follows every reconstruction. Attention
scores do not certify stability, accuracy, or admissibility of future means.
"""

import numpy as np

from tci.guarded import GuardedSlopeLimiter, bound_theta, scale_slopes, invariant_features


EXPERTS = ('guard', 'flat', 'sharpen-1.5', 'sharpen-2', 'least-squares', 'least-squares-2')
TOKEN_DIM = 18


def maximum_face_jump(solver,u):
    """Only the paired trace jump, without constructing unused ML features."""
    jump=np.zeros(solver.K)
    for face in range(3):
        neighbors=solver.all_neighbors[:,face]
        valid=neighbors>=0
        other=neighbors[valid]
        opposite_face=solver.all_neighbor_faces[valid,face]
        trace=u[[face,(face+1)%3],:][:,valid]
        opposite=np.stack([u[(opposite_face+1)%3,other],u[opposite_face,other]])
        jump[valid]=np.maximum(jump[valid],np.max(np.abs(trace-opposite),axis=0))
    return jump


class ReconstructionStencil:
    """Two-hop cell set; geometry uses minimum-image periodic displacements.

    Token 0 is the query cell. Other valid tokens can be permuted freely.
    Missing neighbors are masked, never fabricated as independent observations.
    Coordinates are relative, lengths scaled by sqrt(area), amplitudes by the
    prescribed range. This schema uses fixed [0,1] physical bounds.
    """

    def __init__(self, solver):
        self.solver = solver
        self.h = np.sqrt(solver.mesh.areas)
        self.offsets = solver.mesh.points[solver.mesh.cells]-solver.mesh.centroids[:, None]
        self.indices = np.full((solver.K, 10), -1, dtype=int)
        for k in range(solver.K):
            cells = {k}
            frontier = {k}
            for _ in range(2):
                frontier = {int(n) for j in frontier for n in solver.all_neighbors[j] if n >= 0}-cells
                cells.update(frontier)
            selected = [k]+sorted(cells-{k})
            self.indices[k, :len(selected)] = selected
        self.mask = self.indices >= 0
        self.safe = np.maximum(self.indices, 0)
        self.displacement = solver.mesh.centroids[self.safe]-solver.mesh.centroids[:, None]
        span = np.ptp(solver.mesh.points, axis=0)
        for d, periodic in enumerate(solver.periodic):
            if periodic:
                self.displacement[..., d] -= np.round(self.displacement[..., d]/span[d])*span[d]
        # Least-squares reconstruction from face-neighbor means; pseudoinverse
        # handles boundary stencils without assuming an invertible 2x2 system.
        self.neighbors = np.maximum(solver.all_neighbors, 0)
        valid = solver.all_neighbors >= 0
        dx = solver.mesh.centroids[self.neighbors]-solver.mesh.centroids[:, None]
        for d, periodic in enumerate(solver.periodic):
            if periodic:
                dx[..., d] -= np.round(dx[..., d]/span[d])*span[d]
        weight = valid/np.maximum(np.linalg.norm(dx, axis=-1), 1e-14)
        self.ls = np.linalg.pinv(dx*weight[..., None])*weight[:, None, :]
        self.valid_neighbors = valid

    def encode(self, u):
        solver = self.solver
        features = invariant_features(solver, u, 0, 1)
        means = u.mean(axis=0)
        grad = np.einsum('ik,kid->kd', u, solver.basis_gradients)
        idx, h = self.safe, self.h[:, None]
        velocity = solver.velocity_values(solver.mesh.centroids[:, 0], solver.mesh.centroids[:, 1], 0.)
        speed = np.maximum(np.linalg.norm(velocity, axis=1), 1e-14)
        direction = velocity/speed[:, None]
        shape = self.indices.shape
        x = np.zeros(shape+(TOKEN_DIM,))
        x[..., :2] = self.displacement/h[..., None]
        x[..., 2] = means[idx]-means[:, None]
        x[..., 3:5] = grad[idx]*h[..., None]
        x[..., 5] = features[idx, 4]  # paired trace jump
        x[..., 6] = np.ptp(u, axis=0)[idx]
        x[..., 7] = self.h[idx]/h
        x[..., 8] = features[idx, 10]  # triangle aspect proxy
        x[..., 9] = features[idx, 11]  # physical boundary fraction
        x[..., 10] = means[:, None]
        x[..., 11] = h
        x[..., 12:14] = direction[:, None]
        x[..., 14] = speed[:, None]
        x[..., 15] = features[:, 4, None]
        x[..., 16] = features[:, 1, None]
        x[:, 0, 17] = 1.  # query identity, not an arbitrary position embedding
        x[~self.mask] = 0
        return x.astype(np.float32), self.mask.copy()

    def candidates(self, u):
        mean = u.mean(axis=0)
        delta = u-mean
        diff = (mean[self.neighbors]-mean[:, None])*self.valid_neighbors
        gradient = np.einsum('kdf,kf->kd', self.ls, diff)
        ls_delta = np.einsum('kvd,kd->vk', self.offsets, gradient)
        jump = maximum_face_jump(self.solver,u)
        threshold = .5*self.h**1.5
        gate = np.clip((jump-threshold)/threshold, 0, 1)
        base = scale_slopes(u, bound_theta(u, 0, 1))
        experts = [base]
        for alternative in (np.zeros_like(delta), 1.5*delta, 2*delta, ls_delta, 2*ls_delta):
            proposed = mean+(1-gate)*delta+gate*alternative
            proposed -= proposed.mean(axis=0)-mean
            experts.append(scale_slopes(proposed, bound_theta(proposed, 0, 1)))
        return np.stack(experts, axis=-1)


class GuardedReconstructionLimiter(GuardedSlopeLimiter):
    """Select a mean-preserving expert, then apply the physical guard again.

    Policy returns integer expert indices. Invalid predictions fall back cell by
    cell to guard-only. The existing RK integrator rejects inadmissible means.
    Time-dependent velocities are not encoded by this experimental policy.
    """

    def __init__(self, policy):
        super().__init__(0, 1)
        self.policy = policy
        self.stencil = None

    def apply(self, solver, u, *, initial=False):
        if initial:
            return super().apply(solver, u, initial=True)
        if self.stencil is None or self.stencil.solver is not solver:
            self.stencil = ReconstructionStencil(solver)
        candidates = self.stencil.candidates(u)
        choice = np.asarray(self.policy(self.stencil, u), dtype=float)
        if choice.shape != (solver.K,):
            raise ValueError('reconstruction policy must return K expert indices')
        valid = np.isfinite(choice) & (choice >= 0) & (choice < len(EXPERTS)) & (choice == np.floor(choice))
        self.invalid_predictions += int((~valid).sum())
        choice = np.where(valid, choice, 0).astype(int)
        result = candidates[:, np.arange(solver.K), choice]
        result = scale_slopes(result, bound_theta(result, 0, 1))
        return result, {'minimum':float(result.min()), 'maximum':float(result.max()),
                        'limited_fraction':float(np.mean(np.any(np.abs(result-u)>1e-12, axis=0))),
                        'mean_damping':0., 'guard_fraction':float(np.mean(choice == 0)),
                        'reconstruction_fraction':float(np.mean(choice > 0))}


def reconstruction_costs(operator, stencil, original, candidate, stage, dt, quadrature,
                         reference, horizon=4, chunk=32):
    """Single-cell interventions, with the actual remaining SSP-RK3 stages.

    ``original`` is the accepted state at the beginning of the current step.
    ``candidate`` is the pre-limiter stage 1, 2, or 3 value. The oracle completes
    that step then horizon-1 full guard-only steps. All experts keep candidate
    means. Joint choices are evaluated separately; they are not an upper bound.
    """
    if stage not in (1, 2, 3) or horizon < 1:
        raise ValueError('stage must be 1..3 and horizon positive')
    experts = stencil.candidates(candidate)

    def finish(v):
        base = original if v.ndim == 2 else original[..., None]
        if stage == 1:
            v = operator.guard(.75*base+.25*(v+dt*operator.rhs(v)))
        if stage <= 2:
            v = operator.guard(base/3+2/3*(v+dt*operator.rhs(v)))
        for _ in range(horizon-1):
            v = operator.step(v, dt)
        return v

    moments = quadrature.reference_moments(reference)
    def cost(v):
        return stencil.solver.mesh.areas @ quadrature.squared_error_from_moments(v, moments)
    baseline = float(cost(finish(experts[..., 0])))
    costs = np.full((stencil.solver.K, len(EXPERTS)), baseline)
    for action in range(1, len(EXPERTS)):
        active = np.flatnonzero(np.max(np.abs(experts[..., action]-experts[..., 0]), axis=0)>1e-13)
        for start in range(0, len(active), chunk):
            cells = active[start:start+chunk]
            batch = np.repeat(experts[..., :1], len(cells), axis=-1)
            batch[:, cells, np.arange(len(cells))] = experts[:, cells, action]
            costs[cells, action] = cost(finish(batch))
    choice = costs.argmin(axis=1)
    joint = float(cost(finish(experts[:, np.arange(stencil.solver.K), choice])))
    return costs, {'baseline':baseline, 'joint_oracle':joint,
                   'beneficial_fraction':float(np.mean(choice > 0))}
