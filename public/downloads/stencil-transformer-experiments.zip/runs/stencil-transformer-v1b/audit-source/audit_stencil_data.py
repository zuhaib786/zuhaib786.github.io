"""Quadrature sensitivity of counterfactual labels on six validation trajectories.

This is an audit, not a training/selection step. It keeps the original initial
projection and state fixed while refining only the future reference quadrature.
"""

import argparse
import json
from pathlib import Path

import numpy as np

from scripts.train_stencil_transformer import training_case, write_json, sha
from tci.guarded import GuardedSlopeLimiter
from tci.quadrature import TriangleQuadrature
from tci.reconstruction import ReconstructionStencil, reconstruction_costs
from tci.rollout import BatchedGuardedOperator


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, default=Path('runs/stencil-transformer-v1b'))
    args = parser.parse_args()
    config = json.loads((args.run/'manifest.json').read_text())['config']
    rows = []
    for group in [36,37,38,45,46,47]:
        solver, reference = training_case(group,config)
        q = TriangleQuadrature(solver.mesh,6,2)
        fine = TriangleQuadrature(solver.mesh,6,3)
        stencil, op = ReconstructionStencil(solver), BatchedGuardedOperator(solver)
        controller = GuardedSlopeLimiter(0,1)
        u,_ = controller.apply(solver,q.project(lambda x,y:reference(x,y,0)),initial=True)
        dt = solver.stable_dt(config['cfl'])
        for steps in [0,24]:
            if steps:
                u,_ = solver.solve_guarded(u,steps*dt,controller,cfl=config['cfl'])
            candidate = u+dt*solver.rhs(u)
            future = lambda x,y:reference(x,y,(steps+config['horizon_steps'])*dt)
            a,_ = reconstruction_costs(op,stencil,u,candidate,1,dt,q,future,config['horizon_steps'])
            b,_ = reconstruction_costs(op,stencil,u,candidate,1,dt,fine,future,config['horizon_steps'])
            ga,gb = (a[:,:1]-a)/solver.mesh.areas[:,None],(b[:,:1]-b)/solver.mesh.areas[:,None]
            winners = a.argmin(axis=1)
            regret = gb.max(axis=1)-gb[np.arange(solver.K),winners]
            rows.append(dict(group=group,steps=steps,maximum_advantage_change=float(np.max(np.abs(ga-gb))),
                             action_disagreement_fraction=float(np.mean(winners!=b.argmin(axis=1))),
                             coarse_choice_fine_regret=float(solver.mesh.areas@regret),
                             fine_noop_regret=float(solver.mesh.areas@gb.max(axis=1))))
    result = dict(rows=rows, audit_source_sha256=sha(Path(__file__)),
                  note='Diagnostic only; no checkpoints, labels or thresholds changed after this audit.')
    write_json(args.run/'quadrature-label-audit.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
