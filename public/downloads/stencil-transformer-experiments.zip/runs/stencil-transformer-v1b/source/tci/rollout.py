"""Short-rollout action labels and a guarded, locally invariant ML policy."""

import numpy as np
from scipy.sparse import csr_matrix

from tci.guarded import bound_theta, invariant_features, scale_slopes


def jump_prior(solver, u):
    return 1 - np.minimum(invariant_features(solver, u, 0, 1)[:, 4], 1)**2


class MRSSlopeProposal:
    """Scalar P1 specialization of Moe, Rossmanith & Seal (2015), eqs 8–12.

    Face-neighbor extrema, h=max edge length on the unit domain,
    alpha=C*h^1.5 and phi(r)=min(r/1.1,1). The separate physical bound guard
    remains active. Constant C is frozen in the experiment config.
    """

    def __init__(self, coefficient=1.0):
        if not np.isfinite(coefficient) or coefficient < 0:
            raise ValueError("coefficient must be finite and nonnegative")
        self.coefficient = coefficient

    def __call__(self, solver, u):
        means, low, high = u.mean(axis=0), u.min(axis=0), u.max(axis=0)
        neighbors = solver.all_neighbors
        valid = neighbors >= 0
        safe = np.maximum(neighbors, 0)
        alpha = self.coefficient * np.max(solver.mesh.edge_lengths, axis=1)**1.5
        upper = np.maximum(means+alpha, np.max(np.where(valid, high[safe], -np.inf), axis=1))
        lower = np.minimum(means-alpha, np.min(np.where(valid, low[safe], np.inf), axis=1))
        upper_ratio = np.full(solver.K, np.inf)
        lower_ratio = np.full(solver.K, np.inf)
        np.divide(upper-means, high-means, out=upper_ratio, where=high > means)
        np.divide(lower-means, low-means, out=lower_ratio, where=low < means)
        return np.clip(np.minimum(upper_ratio, lower_ratio)/1.1, 0, 1)


class BatchedGuardedOperator:
    """Offline oracle only: freeze an autonomous homogeneous linear DG RHS.

    Columns are constructed from the existing spatial operator and used for
    many independent interventions. Restricted to periodic constant velocity,
    with the exact same P1 guard and RK stages as the production path.
    """

    def __init__(self, solver):
        if callable(solver.velocity) or not all(solver.periodic) or solver.boundary_func is not None:
            raise ValueError("offline operator requires periodic constant velocity without boundary data")
        self.solver = solver
        self.K = solver.K
        size = 3*self.K
        basis = np.zeros((3, self.K))
        columns = []
        for i in range(size):
            basis.flat[i] = 1
            columns.append(solver.rhs(basis).ravel())
            basis.flat[i] = 0
        self.matrix = csr_matrix(np.column_stack(columns))

    def rhs(self, u):
        return (self.matrix @ u.reshape(3*self.K, -1)).reshape(u.shape)

    def guard(self, u):
        shape = u.shape
        flat = u.reshape(3, -1)
        return scale_slopes(flat, bound_theta(flat, 0, 1)).reshape(shape)

    def step(self, u, dt):
        v1 = self.guard(u+dt*self.rhs(u))
        v2 = self.guard(.75*u+.25*(v1+dt*self.rhs(v1)))
        return self.guard(u/3+2/3*(v2+dt*self.rhs(v2)))

    def action_costs(self, candidate, dt, reference_quadrature, reference,
                     actions=(0., .25, .5, 1.), horizon=4, chunk=32):
        """Change ONE cell's stage slope; advance all affected cells afterwards.

        Interventions are compared to the same untouched state. Labels do not
        represent a jointly optimal action vector. Subsequent steps use only
        the guard. Costs are global area-integrated analytic-reference L2².
        """
        if horizon < 1 or chunk < 1:
            raise ValueError("horizon and chunk must be positive")
        actions = np.asarray(actions)
        if actions.ndim != 1 or not len(actions) or np.any((actions < 0) | (actions > 1)):
            raise ValueError("actions must be damping strengths in [0,1]")
        features = invariant_features(self.solver, candidate, 0, 1)
        gate = np.minimum(features[:, 4], 1)**2
        safe = bound_theta(candidate, 0, 1)
        base = scale_slopes(candidate, safe)
        future = base.copy()
        for _ in range(horizon):
            future = self.step(future, dt)
        moments = reference_quadrature.reference_moments(reference)
        baseline = reference_quadrature.squared_error_from_moments(future, moments)
        baseline_total = float(self.solver.mesh.areas @ baseline)
        costs = np.full((self.K, len(actions)), baseline_total)
        # No effect is possible if the physical guard already dominates.
        active = np.flatnonzero(1-gate < safe-1e-14)
        for start in range(0, len(active), chunk):
            cells = active[start:start+chunk]
            for j, action in enumerate(actions):
                if action == 0:
                    continue
                batch = np.repeat(base[:, :, None], len(cells), axis=2)
                for b, k in enumerate(cells):
                    theta = min(1-gate[k]*action, safe[k])
                    mean = candidate[:, k].mean()
                    batch[:, k, b] = mean+theta*(candidate[:, k]-mean)
                for _ in range(horizon):
                    batch = self.step(batch, dt)
                errors = reference_quadrature.squared_error_from_moments(batch, moments)
                costs[cells, j] = self.solver.mesh.areas @ errors
        return features, costs, baseline_total


class RolloutSlopeModel:
    """Predict action advantages over no extra damping from a local stencil.

    A no-op is always available with predicted advantage zero. Ties and weak
    predicted gains choose no-op. Confidence is a selection device only; the
    physical bound guard is independent of these scores.
    """

    def __init__(self, path):
        with np.load(path, allow_pickle=False) as data:
            if int(data["schema_version"]) != 1:
                raise ValueError("unsupported rollout schema")
            self.w1, self.b1 = data["w1"], data["b1"]
            self.w2, self.b2 = data["w2"], data["b2"]
            self.center, self.scale = data["center"], data["scale"]
            self.actions = data["actions"]
            self.margin = float(data["margin"])

    def __call__(self, solver, u):
        x = invariant_features(solver, u, 0, 1)
        z = (x-self.center)/self.scale
        scores = np.maximum(z@self.w1.T+self.b1, 0)@self.w2.T+self.b2
        choice = np.argmax(scores, axis=1)
        benefit = np.max(scores, axis=1)
        strength = np.where(benefit > self.margin, self.actions[choice], 0)
        return 1-np.minimum(x[:, 4], 1)**2*strength
