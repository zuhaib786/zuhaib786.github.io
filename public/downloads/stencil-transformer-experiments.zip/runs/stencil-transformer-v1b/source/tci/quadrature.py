"""Positive composite triangle quadrature and analytic-reference error norms."""

import numpy as np
from numpy.polynomial.legendre import leggauss


class TriangleQuadrature:
    """Duffy Gauss rule on uniformly subdivided affine triangles.

    Weights sum to one; multiply by physical cell areas. Discontinuous
    references require a refinement check, not just polynomial exactness.
    """

    def __init__(self, mesh, order=6, subdivisions=0):
        if not isinstance(order, int) or order < 2:
            raise ValueError("order must be an integer >= 2")
        if not isinstance(subdivisions, int) or not 0 <= subdivisions <= 5:
            raise ValueError("subdivisions must be an integer in [0, 5]")
        nodes, weights = leggauss(order)
        nodes, weights = (nodes + 1) / 2, weights / 2
        r, s = np.meshgrid(nodes, nodes, indexing="ij")
        local = np.stack([1-r, r*(1-s), r*s], axis=-1).reshape(-1, 3)
        local_weights = (2*r*weights[:, None]*weights[None, :]).ravel()
        triangles = [np.eye(3)]
        for _ in range(subdivisions):
            children = []
            for a, b, c in triangles:
                ab, bc, ca = (a+b)/2, (b+c)/2, (c+a)/2
                children.extend([np.array(t) for t in
                                 [(a, ab, ca), (ab, b, bc), (ca, bc, c), (ab, bc, ca)]])
            triangles = children
        self.barycentric = np.concatenate([local @ triangle for triangle in triangles])
        self.weights = np.tile(local_weights / len(triangles), len(triangles))
        self.areas = mesh.areas
        self.points = np.einsum("qi,kid->qkd", self.barycentric, mesh.points[mesh.cells])

    def sample(self, function):
        values = np.broadcast_to(np.asarray(function(self.points[..., 0], self.points[..., 1]),
                                              dtype=float), self.points.shape[:2])
        if not np.isfinite(values).all():
            raise ValueError("reference must be finite at quadrature points")
        return values

    def project(self, function):
        """L2 projection to P1 using this quadrature, without bound scaling."""
        values = self.sample(function)
        load = np.einsum("q,qi,qk->ik", self.weights, self.barycentric, values)
        return (12*np.eye(3)-3*np.ones((3, 3))) @ load

    def errors(self, u, function):
        if np.shape(u) != (3, len(self.areas)):
            raise ValueError("expected scalar P1 nodal array")
        error = self.barycentric @ u - self.sample(function)
        measure = self.weights[:, None]*self.areas[None, :]
        return {"l1": float(np.sum(measure*np.abs(error))),
                "l2": float(np.sqrt(np.sum(measure*error**2)))}

    def reference_moments(self, function):
        values = self.sample(function)
        return (np.einsum("q,qi,qk->ik", self.weights, self.barycentric, values),
                np.einsum("q,qk->k", self.weights, values**2))

    def squared_error_from_moments(self, u, moments):
        """Exact quadratic in P1 coefficients for a fixed quadrature reference.

        Accepts (3,K) or (3,K,B); avoids sampling every oracle candidate.
        """
        load, reference_square = moments
        matrix = (np.eye(3)+np.ones((3, 3)))/12
        return (np.einsum("ik...,ij,jk...->k...", u, matrix, u)
                - 2*np.einsum("ik,ik...->k...", load, u)
                + reference_square.reshape((-1,)+(1,)*(u.ndim-2)))
