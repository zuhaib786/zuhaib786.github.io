# Transformer reconstruction evidence

Both numerical designs and every selected seed are retained, including timeouts.
Read docs/transformer-results.md first. Models are experimental; use the recorded
acceptance decisions rather than interpreting a checkpoint as a recommendation.

The tci/ and scripts/ trees are consolidated code, including later inference and
reporting improvements. Each runs/*/source/ tree is the exact source frozen for
that experiment. The original summary.json is retained. post-assessment/ reports
failed runs explicitly and contains its assessment source. audit-source/ holds
the exact label-audit source. The optimized-inference-source/ tree and measurements
are a separate follow-up that checks fields against the frozen evaluation.

The excluded first data attempt was stopped before evaluation because mesh type
correlated with field family. Its data and checkpoints are not in the training
sets here. Its exclusion record is retained for provenance.

BUNDLE-MANIFEST.json hashes all other entries. No repository credentials or
unrelated user files are included. No checkpoint or result was published by the
experiment scripts themselves.
