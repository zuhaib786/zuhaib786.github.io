"""Bundle completed experiments and verify every archived byte against hashes."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    files={}
    field_count=0
    for name in ['stencil-transformer-v1b','transport-transformer-v2']:
        root=Path('runs')/name
        rows=json.loads((root/'evaluation.json').read_text())
        if len(rows)!=99:raise SystemExit('Scheduled evaluations are not finished.')
        manifest=json.loads((root/'manifest.json').read_text())
        for file,digest in manifest['source_sha256'].items():
            assert sha((root/'source'/file).read_bytes())==digest,file
        for model in json.loads((root/'frozen-models.json').read_text()):
            assert sha((root/'models'/model['checkpoint']).read_bytes())==model['sha256']
        for row in rows:
            if row['status']=='ok':
                assert sha((root/row['field']).read_bytes())==row['field_sha256']
                field_count+=1
        audit=json.loads((root/'quadrature-label-audit.json').read_text())
        assert sha((root/'audit-source/audit_stencil_data.py').read_bytes())==audit['audit_source_sha256']
        if (root/'optimized-inference.json').exists():
            optimized=json.loads((root/'optimized-inference.json').read_text())
            for file,digest in optimized['source_sha256'].items():
                assert sha((root/'optimized-inference-source'/file).read_bytes())==digest,file
        assessment=json.loads((root/'post-assessment/provenance.json').read_text())
        assert sha((root/'post-assessment/assessment-source.py').read_bytes())==assessment['assessment_source_sha256']
        for path in root.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:
                files[str(path)]=path.read_bytes()
    paths=[Path('README.md'),Path('pyproject.toml'),Path('LICENSE'),*Path('tci').rglob('*.py'),
           *Path('tests').glob('*.py'),Path('scripts/train_stencil_transformer.py'),
           Path('scripts/train_transport_transformer.py'),Path('scripts/audit_stencil_data.py'),
           Path('scripts/plot_stencil_transformer.py'),Path('scripts/summarize_transformers.py'),
           Path('scripts/benchmark_transport_inference.py'),Path(__file__).resolve().relative_to(Path.cwd()),
           Path('configs/stencil-transformer-v1.json'),Path('configs/transport-transformer-v2.json'),
           Path('docs/stencil-transformer-v1.md'),Path('docs/transport-transformer-v2.md'),
           Path('docs/transformer-results.md'),Path('docs/transformer-comparison.json')]
    paths += list(Path('docs/figures').glob('*transformer*'))
    paths += [Path('scripts/train_rollout_limiter.py'),Path('configs/rollout-limiter-v1.json')]
    for path in paths:files[str(path)]=path.read_bytes()
    files['excluded-attempt/ABORTED.json']=Path('runs/stencil-transformer-v1/ABORTED.json').read_bytes()
    files['BUNDLE-README.md']=('''# Transformer reconstruction evidence

Both numerical designs and every selected seed are retained, including timeouts.
Read docs/transformer-results.md first. Models are experimental; use the recorded
acceptance decisions rather than interpreting a checkpoint as a recommendation.

The tci/ and scripts/ trees are consolidated code, including later inference and
reporting improvements. Each runs/*/source/ tree is the exact source frozen for
that experiment. The original summary.json is retained. post-assessment/ reports
failed runs explicitly and contains its assessment source. audit-source/ holds
the exact label-audit source. The optimized-inference-source/ tree and measurements
are a separate follow-up that checks fields against the frozen evaluation.

The excluded first data attempt was stopped before evaluation because mesh type
correlated with field family. Its data and checkpoints are not in the training
sets here. Its exclusion record is retained for provenance.

BUNDLE-MANIFEST.json hashes all other entries. No repository credentials or
unrelated user files are included. No checkpoint or result was published by the
experiment scripts themselves.
''').encode()
    files['BUNDLE-MANIFEST.json']=json.dumps({name:{'sha256':sha(data),'bytes':len(data)} for name,data in files.items()},indent=2).encode()
    args.out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,data in sorted(files.items()):archive.writestr(name,data)
    with zipfile.ZipFile(args.out) as archive:
        assert archive.testzip() is None
        for name,record in json.loads(archive.read('BUNDLE-MANIFEST.json')).items():
            assert sha(archive.read(name))==record['sha256']
    print(json.dumps(dict(files=len(files),verified_fields=field_count,megabytes=args.out.stat().st_size/1e6)))


if __name__=='__main__':main()
