"""Write an evidence table only after both transformer designs finish."""

import json
from pathlib import Path

import numpy as np

from scripts.train_stencil_transformer import summarize,write_json,sha


def main():
    output = ['# Transformer reconstruction: measured results', '',
              'All seeds are reported. Positive sharp-case improvement means lower L1 error than guard-only.',
              'The two designs use different final parameters; their absolute errors are not paired comparisons.', '']
    combined = {}
    for name,title in [('stencil-transformer-v1b','Instantaneous reconstruction'),
                       ('transport-transformer-v2','Time-relaxed reconstruction')]:
        root = Path('runs')/name
        rows = json.loads((root/'evaluation.json').read_text())
        config = json.loads((root/'manifest.json').read_text())['config']
        post=root/'post-assessment';post.mkdir(exist_ok=True)
        summary=summarize(post,config,rows)
        write_json(post/'provenance.json',{'reason':'Report failed runs explicitly without averaging a partial seed.',
                   'assessment_source_sha256':sha(Path('scripts/train_stencil_transformer.py'))})
        (post/'assessment-source.py').write_bytes(Path('scripts/train_stencil_transformer.py').read_bytes())
        if not summary['complete']:
            raise SystemExit(f'{name}: still missing scheduled cases.')
        combined[name] = summary
        guard_by_case={(r['problem'],r['mesh'],r['n']):r for r in rows if r['method']=='guard' and r['status']=='ok'}
        fixed=[r for r in rows if r['method']=='fixed-sharpen' and r['problem']!='smooth' and r['status']=='ok']
        fixed_gains=[1-r['l1']/guard_by_case[(r['problem'],r['mesh'],r['n'])]['l1'] for r in fixed]
        if name=='transport-transformer-v2':
            output[4:4]=['',f'**The positive accuracy result is the deterministic control:** mean sharp-case L1 error falls by '
                         f'{100*np.mean(fixed_gains):.2f}%, with gains of {100*min(fixed_gains):.2f}–{100*max(fixed_gains):.2f}% '
                         'on all eight sharp cases. It matches the tested smooth accuracy. The learned models do not improve on that control consistently.', '']
        output += [f'## {title}', '',
            f'{summary["attempts"]} runs attempted; {summary["failures"]} failed. Adopt attention: **{summary["adopt"]}**.', '',
            '| Model | Mean sharp L1 improvement | Worst sharp L1 ratio | Final smooth order | Mean runtime / guard | Failed gates |',
            '|---|---:|---:|---:|---:|---|']
        for model in summary['models']:
            failures=', '.join(k for k,v in model['checks'].items() if not v) or 'none'
            if 'sharp_l1_improvement' not in model:
                output.append(f'| {model["method"]} | — | — | — | — | {model.get("reason",failures)} |')
                continue
            output.append(f'| {model["method"]} | {100*model["sharp_l1_improvement"]:+.2f}% | '
                          f'{model["worst_l1_ratio"]:.3f} | {model["smooth_order"]:.3f} | '
                          f'{model["mean_runtime_ratio"]:.2f} | {failures} |')
        output += ['', 'Finest sharp cases; learned columns average all three seeds.', '',
                   '| Case | Guard L1 | Fixed sharpening L1 | Attention mean L1 | Pooling mean L1 |',
                   '|---|---:|---:|---:|---:|']
        n=max(r['n'] for r in rows if r['problem']!='smooth')
        for p in ['diamond-ring','rotation-slot']:
            for mesh in ['structured','delaunay']:
                selected=[r for r in rows if (r['problem'],r['mesh'],r['n'])==(p,mesh,n)]
                guard=next(r['l1'] for r in selected if r['method']=='guard')
                fixed=next(r['l1'] for r in selected if r['method']=='fixed-sharpen')
                def mean_text(prefix):
                    sample=[r for r in selected if r['method'].startswith(prefix)]
                    return f'{np.mean([r["l1"] for r in sample]):.6f}' if all(r['status']=='ok' for r in sample) else 'failed seed'
                output.append(f'| {p}, {mesh}, n={n} | {guard:.6f} | {fixed:.6f} | {mean_text("attention-")} | {mean_text("pool-")} |')
        successful=[r for r in rows if r['status']=='ok']
        bound=max(max(0,-r['minimum'],r['maximum']-1) for r in successful)
        mass=max(abs(r['conservation_residual']) for r in successful)
        quadrature=max(r['quadrature_change'] for r in successful)
        output += ['',f'Across successful runs: maximum bound violation {bound:.3e}; maximum boundary-accounted '
                   f'mass residual {mass:.3e}; maximum L1 quadrature refinement change {100*quadrature:.4f}%.','']
        n=max(r['n'] for r in rows if r['problem']=='smooth')
        smooth=[r for r in rows if r['problem']=='smooth' and r['n']==n]
        guard=next(r['l2'] for r in smooth if r['method']=='guard')
        ratios=[r['l2']/guard for r in smooth if r['method'].startswith('attention-')]
        output += [f'At the finest smooth mesh n={n}, attention L2 / guard L2 ranges from '
                   f'{min(ratios):.3f} to {max(ratios):.3f}. A convergence-rate gate alone does not bound absolute error.','']
    output += ['## Decision and limits', '',
        'Neither checkpoint family is promoted unless every attention seed passes every gate. '
        'Physical bounds do not establish low error, entropy stability or long-time robustness. '
        'The timestep correction changes the action, sensor and data distribution together, '
        'so the second design does not isolate any one of those factors.', '',
        'Timings come from a shared host with some overlapping experiment work. '
        'They include inference and geometry setup, and exclude reference-error quadrature. '
        'Precise deployment cost needs isolated repeated measurements.', '',
        'The first aborted data-generation attempt was excluded before evaluation. '
        'Both completed runs retain source/configuration snapshots, datasets, model and field hashes. '
        'Final cases were not used to select checkpoints. The second design uses known benchmark '
        'families with new parameters and meshes; it is not an external blind test.', '']
    benchmark=Path('runs/transport-transformer-v2/optimized-inference.json')
    if benchmark.exists():
        measurements=json.loads(benchmark.read_text())['records']
        output += ['## Optimized inference check', '',
            'These subsequent measurements use the same checkpoints and numerical decisions. '
            'Unused features and candidates are skipped. Each case/method has three repeats; '
            'ratios below divide method median time by paired guard median time.', '',
            '| Case | Guard median (s) | Attention seed 0 median (s) | Fixed reconstruction median (s) | Attention / guard | Fixed / guard |',
            '|---|---:|---:|---:|---:|---:|']
        for case in sorted({(r['problem'],r['mesh'],r['n']) for r in measurements}):
            med={m:float(np.median([r['runtime_s'] for r in measurements if (r['problem'],r['mesh'],r['n'])==case and r['method']==m]))
                 for m in ['guard','attention-0','fixed-sharpen']}
            output.append(f'| {case[0]}, {case[1]}, n={case[2]} | {med["guard"]:.3f} | {med["attention-0"]:.3f} | '
                          f'{med["fixed-sharpen"]:.3f} | {med["attention-0"]/med["guard"]:.2f} | {med["fixed-sharpen"]/med["guard"]:.2f} |')
        error=max(r['max_nodal_difference'] for r in measurements)
        output += ['',f'The maximum nodal difference from the saved frozen fields is {error:.3e}. '
                   'This checks numerical equivalence on the three selected cases; it is not a new accuracy evaluation or a full runtime acceptance test. '
                   'The host still shows timing variation, so these small samples do not establish deployment-wide performance.', '']
    Path('docs/transformer-results.md').write_text('\n'.join(output))
    Path('docs/transformer-comparison.json').write_text(json.dumps(combined,indent=2)+'\n')


if __name__=='__main__':main()
