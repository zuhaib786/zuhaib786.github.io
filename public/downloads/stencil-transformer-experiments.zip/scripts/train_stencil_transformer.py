#!/usr/bin/env python
"""Frozen local-attention reconstruction experiment; refuses existing output.

Run: .venv/bin/python -m scripts.train_stencil_transformer
The final evaluation is opened only after both architectures are frozen.
"""

import argparse
import hashlib
import json
import platform
import subprocess
import time
from pathlib import Path

import numpy as np
import torch

from tci.evaluate2d import rotational_velocity
from tci.guarded import GuardedSlopeLimiter
from tci.mesh import rectangular_mesh, perturbed_delaunay_mesh
from tci.quadrature import TriangleQuadrature
from tci.reconstruction import ReconstructionStencil, GuardedReconstructionLimiter, reconstruction_costs, EXPERTS
from tci.rollout import BatchedGuardedOperator, MRSSlopeProposal
from tci.solvers.dg2d import AdvectionDG2D
from tci.stencil_attention import StencilNetwork, StencilPolicy


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def base_revision():
    """Source hashes remain authoritative when running an extracted archive."""
    try:
        return subprocess.check_output(['git','rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
    except (OSError,subprocess.CalledProcessError):
        return None


def training_case(group, config):
    rng = np.random.default_rng(config['data_seed']+group)
    n = config['training_resolutions'][(group//6) % 2]
    mesh = (rectangular_mesh(nx=n, ny=n) if (group//6+group//12) % 2 == 0 else
            perturbed_delaunay_mesh(nx=n, ny=n, jitter=.22, seed=group+1300))
    angle = rng.uniform(0, 2*np.pi)
    velocity = rng.uniform(.3, 1.0)*np.array([np.cos(angle), np.sin(angle)])
    phase = rng.uniform(0, 1, 2)
    width = rng.uniform(.07, .23)
    mode = group % 6

    def reference(x, y, t):
        xx, yy = (x-velocity[0]*t-phase[0]) % 1, (y-velocity[1]*t-phase[1]) % 1
        if mode == 0:
            return .5+.3*np.sin(2*np.pi*xx)*np.cos(2*np.pi*yy)
        if mode == 1:
            return ((xx>.25)&(xx<.25+width)&(yy>.2)&(yy<.7)).astype(float)
        if mode == 2:
            return ((xx-.5)**2+(yy-.5)**2<width**2).astype(float)
        if mode == 3:
            return .5+.4*np.tanh(np.sin(2*np.pi*(xx+yy))/(width/2))
        if mode == 4:
            return .1+.8*np.exp(-((xx-.5)**2+(yy-.5)**2)/width**2)
        return (((xx+yy) % 1) < width).astype(float)*.7+.1
    return AdvectionDG2D(mesh, velocity=velocity, periodic=(True, True)), reference


def collect(out, config, policy=None):
    out.mkdir()
    data = {k:[] for k in ['x', 'mask', 'costs', 'groups', 'areas']}
    records = []
    count = config['train_trajectories']+(config['validation_trajectories'] if policy is None else 0)
    for group in range(count):
        started = time.perf_counter()
        solver, reference = training_case(group, config)
        q = TriangleQuadrature(solver.mesh, config['quadrature_order'], 2)
        stencil = ReconstructionStencil(solver)
        op = BatchedGuardedOperator(solver)
        controller = GuardedSlopeLimiter(0, 1) if policy is None else GuardedReconstructionLimiter(policy)
        u, _ = controller.apply(solver, q.project(lambda x, y:reference(x, y, 0)), initial=True)
        dt, t = solver.stable_dt(config['cfl']), 0.
        for snapshot in range(config['snapshots']):
            stage = snapshot % 3+1
            candidate = u+dt*solver.rhs(u)
            if stage > 1:
                v1, _ = controller.apply(solver, candidate)
                candidate = .75*u+.25*(v1+dt*solver.rhs(v1))
            if stage > 2:
                v2, _ = controller.apply(solver, candidate)
                candidate = u/3+2/3*(v2+dt*solver.rhs(v2))
            final_time = t+config['horizon_steps']*dt
            costs, record = reconstruction_costs(op, stencil, u, candidate, stage, dt, q,
                            lambda x, y:reference(x, y, final_time), config['horizon_steps'])
            x, mask = stencil.encode(candidate)
            for k, value in dict(x=x, mask=mask, costs=costs,
                                 groups=np.full(solver.K, group), areas=solver.mesh.areas).items():
                data[k].append(value)
            records.append(dict(group=group, split='train' if group<config['train_trajectories'] else 'validation',
                                family=group%6, snapshot=snapshot, stage=stage, time=t, dt=dt,
                                cells=solver.K, **record))
            duration = config['snapshot_spacing_steps']*dt
            u, _ = solver.solve_guarded(u, duration, controller, cfl=config['cfl'])
            t += duration
        print(f'{out.name} group {group+1}/{count} ({time.perf_counter()-started:.2f}s)', flush=True)
    data = {k:np.concatenate(v) for k,v in data.items()}
    np.savez_compressed(out/'data.npz', **data)
    write_json(out/'oracle.json', records)
    return data


def fit(out, data, config, architectures, seeds):
    out.mkdir()
    train = data['groups'] < config['train_trajectories']
    valid = ~train
    actual = data['x'][train][data['mask'][train]]
    center = actual.mean(axis=0)
    scale = np.maximum(actual.std(axis=0), .02)
    gains = (data['costs'][:, :1]-data['costs'][:, 1:])/data['areas'][:, None]
    if 'action_scale' in data:
        gains /= np.maximum(data['action_scale'][:,None],1e-12)
    target = np.clip(gains/config['score_scale'], -20, 20)
    x = torch.tensor((data['x']-center)/scale)
    mask = torch.tensor(data['mask'])
    y = torch.tensor(target, dtype=torch.float32)
    weights = np.zeros(len(x))
    for group in np.unique(data['groups']):
        member = data['groups'] == group
        weights[member] = 1/member.sum()
    weights /= weights[train].mean()
    wt = torch.tensor(weights, dtype=torch.float32)
    train_ids = np.flatnonzero(train)
    all_gains = np.column_stack([np.zeros(valid.sum()), gains[valid]])
    summaries = []
    for architecture in architectures:
        for seed in seeds:
            torch.manual_seed(seed)
            rng = np.random.default_rng(seed)
            model = StencilNetwork(architecture, config['width'], input_dim=x.shape[-1])
            optimizer = torch.optim.AdamW(model.parameters(), lr=config['learning_rate'], weight_decay=1e-4)
            best = None
            for epoch in range(config['epochs']):
                model.train()
                permutation = rng.permutation(train_ids)
                for start in range(0, len(permutation), config['batch_size']):
                    idx = permutation[start:start+config['batch_size']]
                    prediction = model(x[idx], mask[idx])
                    loss = (wt[idx]*((prediction-y[idx])**2).mean(dim=1)).mean()
                    optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                    optimizer.step()
                model.eval()
                with torch.inference_mode():
                    scores = model(x[valid], mask[valid]).numpy()
                choices = scores.argmax(axis=1)+1
                choices[scores.max(axis=1)<=config['advantage_margin']] = 0
                regret = all_gains.max(axis=1)-all_gains[np.arange(valid.sum()), choices]
                key = (float(np.average(regret, weights=weights[valid])),
                       float(np.mean((scores-target[valid])**2)))
                if best is None or key<best[0]:
                    best = (key, epoch+1, {k:v.detach().clone() for k,v in model.state_dict().items()})
            path = out/f'{architecture}-{seed}.pt'
            torch.save(dict(schema=1, experts=list(EXPERTS), architecture=architecture, width=config['width'], input_dim=x.shape[-1],
                            state=best[2], center=center.tolist(), scale=scale.tolist(),
                            margin=config['advantage_margin']), path)
            record = dict(architecture=architecture, seed=seed, best_epoch=best[1],
                          validation_regret=best[0][0], validation_score_mse=best[0][1],
                          parameters=sum(p.numel() for p in model.parameters()),
                          checkpoint=path.name, sha256=sha(path))
            summaries.append(record)
            print(json.dumps(record), flush=True)
    write_json(out/'training.json', dict(models=summaries, train_rows=int(train.sum()), validation_rows=int(valid.sum()),
                 no_op_validation_regret=float(np.average(all_gains.max(axis=1), weights=weights[valid]))))
    return summaries


def evaluation_cases(config):
    # Shapes, parameters and meshes differ from the previous published pilot.
    for n in config['smooth_resolutions']:
        solver = AdvectionDG2D(rectangular_mesh(nx=n, ny=n), velocity=(.47, -.81), periodic=(True, True))
        def smooth(x, y, t):
            return .5+.28*np.cos(2*np.pi*(x-.47*t))*np.sin(2*np.pi*(y+.81*t))
        yield 'smooth', 'structured', n, solver, smooth, .12
    for n in config['evaluation_resolutions']:
        for kind in ['structured', 'delaunay']:
            mesh = (rectangular_mesh(nx=n, ny=n) if kind=='structured' else
                    perturbed_delaunay_mesh(nx=n, ny=n, jitter=.3, seed=config['evaluation_mesh_seed']))
            solver = AdvectionDG2D(mesh, velocity=(.47, -.81), periodic=(True, True))
            def shapes(x, y, t):
                xx, yy = (x-.47*t) % 1, (y+.81*t) % 1
                diamond = (np.abs(xx-.3)+np.abs(yy-.3)) < .14
                radius = (xx-.7)**2+(yy-.68)**2
                ring = (radius<.16**2)&(radius>.075**2)
                return .8*diamond.astype(float)+.65*ring.astype(float)
            yield 'diamond-ring', kind, n, solver, shapes, .25
            rotation = AdvectionDG2D(mesh, velocity=rotational_velocity,
                                    boundary_func=lambda x, y, t:np.zeros_like(x))
            def slot(x, y, t):
                angle = -2*np.pi*t
                xx = .5+np.cos(angle)*(x-.5)-np.sin(angle)*(y-.5)
                yy = .5+np.sin(angle)*(x-.5)+np.cos(angle)*(y-.5)
                disk = (xx-.34)**2+(yy-.59)**2 < .14**2
                cut = (np.abs(xx-.34)<.03)&(yy<.62)
                return (disk&~cut).astype(float)
            yield 'rotation-slot', kind, n, rotation, slot, .35


def evaluate(out, config, models, case_factory=evaluation_cases, reconstruction_controller=GuardedReconstructionLimiter):
    methods = [('guard', lambda:GuardedSlopeLimiter(0, 1)),
               ('mrs', lambda:GuardedSlopeLimiter(0, 1, MRSSlopeProposal(1))),
               ('fixed-sharpen', lambda:reconstruction_controller(lambda s,u:np.full(s.solver.K, 2)))]
    for row in models:
        policy = StencilPolicy(out/'models'/row['checkpoint'])
        methods.append((f'{row["architecture"]}-{row["seed"]}', lambda p=policy:reconstruction_controller(p)))
    (out/'fields').mkdir()
    rows = []
    rng = np.random.default_rng(718)
    for problem, mesh, n, solver, exact, final_time in case_factory(config):
        q = TriangleQuadrature(solver.mesh, config['quadrature_order'], 2)
        finer = TriangleQuadrature(solver.mesh, config['quadrature_order'], 3)
        initial, _ = GuardedSlopeLimiter(0, 1).apply(solver, finer.project(lambda x,y:exact(x,y,0)), initial=True)
        # Random method order per case reduces systematic warm-up/drift bias.
        for j in rng.permutation(len(methods)):
            name, factory = methods[j]
            controller = factory()
            row = dict(problem=problem, mesh=mesh, n=n, method=name, final_time=final_time)
            started = time.perf_counter()
            try:
                result, history = solver.solve_guarded(initial, final_time, controller, cfl=config['cfl'],
                                                       max_seconds=config['maximum_seconds_per_run'])
                row['runtime_s'] = time.perf_counter()-started
                stages = [s for step in history for s in step['stages']]
                rough = q.errors(result, lambda x,y:exact(x,y,final_time))
                accurate = finer.errors(result, lambda x,y:exact(x,y,final_time))
                row.update(status='ok', **accurate,
                           quadrature_change=abs(rough['l1']-accurate['l1'])/max(accurate['l1'], 1e-15),
                           minimum=min(s['minimum'] for s in stages), maximum=max(s['maximum'] for s in stages),
                           conservation_residual=solver.integral(result)-solver.integral(initial)-controller.boundary_transport,
                           boundary_transport=controller.boundary_transport, rejected_steps=controller.rejected_steps,
                           invalid_predictions=controller.invalid_predictions,
                           reconstruction_fraction=float(np.mean([s.get('reconstruction_fraction', 0) for s in stages])))
                file = out/'fields'/f'{problem}-{mesh}-{n}-{name}.npz'
                np.savez_compressed(file, points=solver.mesh.points, cells=solver.mesh.cells, initial=initial, result=result)
                row.update(field=str(file.relative_to(out)), field_sha256=sha(file))
            except (RuntimeError, ValueError, TimeoutError) as error:
                row.update(status='failed', error=str(error), runtime_s=time.perf_counter()-started)
            rows.append(row)
            write_json(out/'evaluation.json', rows)
            print(json.dumps(row), flush=True)
    return rows


def summarize(out, config, rows):
    key = lambda r:(r['problem'], r['mesh'], r['n'])
    cases = {('smooth','structured',n) for n in config['smooth_resolutions']}
    cases |= {(p,m,n) for p in ['diamond-ring','rotation-slot'] for m in ['structured','delaunay']
              for n in config['evaluation_resolutions']}
    names = ['guard','mrs','fixed-sharpen']+[f'{a}-{s}' for a in ['attention','pool'] for s in config['initialization_seeds']]
    required = {(*k,m) for k in cases for m in names}
    observed = {(*key(r),r['method']) for r in rows}
    complete = observed == required and len(rows)==len(required)
    result = dict(complete=complete, attempts=len(rows), failures=sum(r['status']!='ok' for r in rows), models=[], adopt=False)
    if complete:
        guard = {key(r):r for r in rows if r['method']=='guard'}
        g = config['acceptance']
        for name in names[3:]:
            selected = [r for r in rows if r['method']==name]
            if any(r['status']!='ok' for r in selected) or any(r['status']!='ok' for r in guard.values()):
                result['models'].append(dict(method=name,accepted=False,checks={'execution':False},
                    reason='A model case or the paired guard control failed. No partial mean is reported.'))
                continue
            sharp = [r for r in selected if r['problem']!='smooth']
            smooth = sorted([r for r in selected if r['problem']=='smooth'], key=lambda r:r['n'])
            ratios = [r['l1']/guard[key(r)]['l1'] for r in sharp]
            classical_ratios = [r['l1']/min(c['l1'] for c in rows if key(c)==key(r) and c['method'] in names[:3] and c['status']=='ok') for r in sharp]
            metric = dict(method=name, sharp_l1_improvement=float(1-np.mean(ratios)), worst_l1_ratio=max(ratios),
                improvement_over_best_classical_per_case=float(1-np.mean(classical_ratios)),
                smooth_order=float(np.log(smooth[-2]['l2']/smooth[-1]['l2'])/np.log(smooth[-1]['n']/smooth[-2]['n'])),
                mean_runtime_ratio=float(np.mean([r['runtime_s']/guard[key(r)]['runtime_s'] for r in selected])),
                max_bound_violation=max(max(0,-r['minimum'],r['maximum']-1) for r in selected),
                max_mass_residual=max(abs(r['conservation_residual']) for r in selected),
                max_quadrature_change=max(r['quadrature_change'] for r in selected))
            checks = dict(improvement=metric['sharp_l1_improvement']>=g['minimum_mean_sharp_l1_improvement'],
                          controls=all(r['status']=='ok' for r in rows if r['method'] in names[:3]),
                          best_classical=metric['improvement_over_best_classical_per_case']>0,
                          regression=metric['worst_l1_ratio']<=g['maximum_case_l1_ratio'],
                          smooth=metric['smooth_order']>=g['minimum_smooth_order'],
                          runtime=metric['mean_runtime_ratio']<=g['maximum_runtime_ratio'],
                          bounds=metric['max_bound_violation']<=g['maximum_bound_violation'],
                          conservation=metric['max_mass_residual']<=g['maximum_mass_residual'],
                          quadrature=metric['max_quadrature_change']<=g['maximum_quadrature_change'])
            metric.update(checks=checks, accepted=all(checks.values()))
            result['models'].append(metric)
        result['adopt'] = result['failures']==0 and all(r['accepted'] for r in result['models'] if r['method'].startswith('attention'))
    write_json(out/'summary.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=Path('configs/stencil-transformer-v1.json'))
    parser.add_argument('--out', type=Path, default=Path('runs/stencil-transformer-v1'))
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit('Use a new output directory; previous evidence is immutable.')
    config = json.loads(args.config.read_text())
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    args.out.mkdir(parents=True)
    source = args.out/'source'; source.mkdir()
    paths = [args.config, Path(__file__).resolve().relative_to(Path.cwd()), *Path('tci').rglob('*.py')]
    hashes = {}
    for path in paths:
        dest = source/path; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(path.read_bytes())
        hashes[str(path)] = sha(path)
    write_json(args.out/'manifest.json', dict(config=config, source_sha256=hashes,
        base_commit=base_revision(),
        python=platform.python_version(), numpy=np.__version__, torch=torch.__version__))
    data = collect(args.out/'guard-data', config)
    provisional = fit(args.out/'behavior-model', data, config, ['attention'], [0])
    policy = StencilPolicy(args.out/'behavior-model'/provisional[0]['checkpoint'])
    extra = collect(args.out/'behavior-data', config, policy)
    data = {k:np.concatenate([data[k], extra[k]]) for k in data}
    models = fit(args.out/'models', data, config, ['attention','pool'], config['initialization_seeds'])
    write_json(args.out/'frozen-models.json', models)
    rows = evaluate(args.out, config, models)
    print(json.dumps(summarize(args.out, config, rows), indent=2), flush=True)


if __name__ == '__main__':
    main()
