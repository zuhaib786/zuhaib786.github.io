"""Render complete frozen reconstruction results without selecting a best seed."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from matplotlib.ticker import NullFormatter
import numpy as np

from scripts.train_stencil_transformer import evaluation_cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path,default=Path('runs/stencil-transformer-v1b'))
    parser.add_argument('--out',type=Path,default=Path('docs/figures'))
    args = parser.parse_args()
    summary_path = args.run/'post-assessment'/'summary.json'
    if not summary_path.exists():summary_path=args.run/'summary.json'
    summary = json.loads(summary_path.read_text())
    if not summary['complete']:
        raise SystemExit('Refusing to plot incomplete evidence as a finished comparison.')
    rows = json.loads((args.run/'evaluation.json').read_text())
    config = json.loads((args.run/'manifest.json').read_text())['config']
    prefix = 'transport-transformer-v2' if config.get('transport_scaled') else 'stencil-transformer-v1'
    args.out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.titleweight':'bold','savefig.facecolor':'white'})
    colors = {'guard':'#263844','mrs':'#91989c','fixed-sharpen':'#bc8831','attention':'#176caa','pool':'#b24f6e'}
    fig,axes = plt.subplots(1,2,figsize=(13,4.8),gridspec_kw={'width_ratios':[1,1.7]},layout='constrained')
    ns = config['smooth_resolutions']
    for name in ['guard','mrs','fixed-sharpen','attention','pool']:
        methods = [name] if name in ['guard','mrs','fixed-sharpen'] else [f'{name}-{s}' for s in config['initialization_seeds']]
        errors = np.array([[next(r['l2'] for r in rows if r['method']==m and r['problem']=='smooth' and r['n']==n)
                           for n in ns] for m in methods])
        axes[0].loglog(ns,errors.mean(axis=0),'o-',color=colors[name],label=name)
        if len(methods)>1:
            axes[0].fill_between(ns,errors.min(axis=0),errors.max(axis=0),color=colors[name],alpha=.15)
    axes[0].set(xlabel='Resolution n',ylabel='Analytic-reference L2 error',title='Smooth convergence')
    axes[0].set_xticks(ns,labels=[str(n) for n in ns]);axes[0].legend(fontsize=9)
    axes[0].xaxis.set_minor_formatter(NullFormatter())
    keys = [(p,m,n) for p in ['diamond-ring','rotation-slot'] for n in config['evaluation_resolutions']
            for m in ['structured','delaunay']]
    for name,offset in [('fixed-sharpen',-.22),('mrs',-.11),('attention',.06),('pool',.23)]:
        methods = [name] if name in ['fixed-sharpen','mrs'] else [f'{name}-{s}' for s in config['initialization_seeds']]
        for j,m in enumerate(methods):
            ratios = []
            for p,mesh,n in keys:
                lookup = {r['method']:r for r in rows if (r['problem'],r['mesh'],r['n'])==(p,mesh,n)}
                ratios.append(lookup[m]['l1']/lookup['guard']['l1'] if lookup[m]['status']=='ok' else np.nan)
            axes[1].scatter(np.arange(len(keys))+offset+(j-(len(methods)-1)/2)*.035,ratios,
                            s=27,color=colors[name],alpha=.8,label=name if j==0 else None)
    axes[1].axhline(1,color=colors['guard'],lw=1)
    axes[1].axhline(.9,color=colors['guard'],lw=.8,ls=':')
    axes[1].set_xticks(range(len(keys)),labels=[f'{"Ring" if p=="diamond-ring" else "Slot"}\n{"S" if m=="structured" else "D"}{n}' for p,m,n in keys])
    axes[1].set(ylabel='L1 error / guard-only L1 error',title='Sharp cases: every seed, lower is better')
    axes[1].legend(fontsize=9,ncol=2)
    axes[1].grid(axis='y',alpha=.15)
    if summary['failures']:
        axes[1].text(.02,.98,f'{summary["failures"]} failed runs; missing results are listed in the report',
                     transform=axes[1].transAxes,va='top',fontsize=8,color='#993333')
    for ext in ['png','svg']:
        fig.savefig(args.out/f'{prefix}.{ext}',dpi=180)
    plt.close(fig)

    case_factory = evaluation_cases
    if config.get('transport_scaled'):
        from scripts.train_transport_transformer import evaluation_cases as case_factory
    case = next(c for c in case_factory(config) if c[0]=='rotation-slot' and c[1]=='delaunay' and c[2]==max(config['evaluation_resolutions']))
    problem,mesh,n,solver,reference,final_time = case
    fig,axes = plt.subplots(1,5,figsize=(16,3.7),layout='constrained')
    gx,gy = np.meshgrid(np.linspace(0,1,400),np.linspace(0,1,400))
    axes[0].imshow(reference(gx,gy,final_time),origin='lower',extent=(0,1,0,1),vmin=0,vmax=1,cmap='viridis')
    axes[0].set_title('Analytic reference')
    for ax,method in zip(axes[1:],['guard','fixed-sharpen','attention-0','pool-0']):
        row = next(r for r in rows if (r['problem'],r['mesh'],r['n'],r['method'])==(problem,mesh,n,method))
        if row['status']!='ok':
            ax.text(.5,.5,'Run failed',ha='center',va='center');ax.set_title(method)
            continue
        with np.load(args.run/row['field']) as data:
            vertices = data['points'][data['cells']].reshape(-1,2)
            triangles = np.arange(len(vertices)).reshape(-1,3)
            artist = ax.tripcolor(mtri.Triangulation(vertices[:,0],vertices[:,1],triangles),data['result'].T.ravel(),
                                 shading='gouraud',vmin=0,vmax=1,cmap='viridis',rasterized=True)
        ax.set_title(f'{method}\nL1 = {row["l1"]:.4f}')
    for ax in axes:
        ax.set(xlim=(.1,.9),ylim=(.1,.9),aspect='equal');ax.set_xticks([]);ax.set_yticks([])
    fig.colorbar(artist,ax=axes,shrink=.75,label='u')
    fig.suptitle(f'Rotating slotted disk • Delaunay n={n} • seed 0',fontsize=12)
    fig.savefig(args.out/f'{prefix}-fields.png',dpi=180)
    plt.close(fig)


if __name__=='__main__':
    main()
