#!/usr/bin/env python
"""Frozen scalar pilot with counterfactual rollout labels and on-policy data.

Run from repository root. Each output directory is immutable: use a new one
for a new experiment. Source/config snapshots precede all dataset generation.
"""

import argparse
import hashlib
import json
import platform
import subprocess
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from tci.evaluate2d import rotational_velocity
from tci.guarded import GuardedSlopeLimiter
from tci.mesh import rectangular_mesh, perturbed_delaunay_mesh
from tci.quadrature import TriangleQuadrature
from tci.rollout import BatchedGuardedOperator, MRSSlopeProposal, RolloutSlopeModel, jump_prior
from tci.solvers.dg2d import AdvectionDG2D


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def training_case(group, config):
    rng = np.random.default_rng(config['data_seed']+group)
    n = config['training_resolutions'][(group//4) % len(config['training_resolutions'])]
    mesh = (rectangular_mesh(nx=n, ny=n) if (group//4+group//8) % 2 == 0 else
            perturbed_delaunay_mesh(nx=n, ny=n, jitter=.18, seed=group+300))
    velocity = rng.uniform(-.9, .9, 2)
    phase = rng.uniform(0, 1, 2)
    width = rng.uniform(.1, .25)
    mode = group % 4

    def reference(x, y, t):
        xx = (x-velocity[0]*t-phase[0]) % 1
        yy = (y-velocity[1]*t-phase[1]) % 1
        if mode == 0:
            return .5+.35*np.sin(2*np.pi*xx)*np.cos(2*np.pi*yy)
        if mode == 1:
            return ((xx > .2) & (xx < .2+width)).astype(float)
        if mode == 2:
            return ((xx-.5)**2+(yy-.5)**2 < width**2).astype(float)
        return .5+.4*np.tanh(np.sin(2*np.pi*(xx+yy))/(width/2))

    return AdvectionDG2D(mesh, velocity=velocity, periodic=(True, True)), reference


def collect(out, config, policy=None, training_only=False):
    features, costs, groups, area = [], [], [], []
    records = []
    count = config['train_trajectories']+(0 if training_only else config['validation_trajectories'])
    for group in range(count):
        started = time.perf_counter()
        solver, reference = training_case(group, config)
        q = TriangleQuadrature(solver.mesh, config['quadrature_order'], 1)
        controller = GuardedSlopeLimiter(0, 1, policy)
        u, _ = controller.apply(solver, q.project(lambda x, y: reference(x, y, 0)), initial=True)
        operator = BatchedGuardedOperator(solver)
        dt, t = solver.stable_dt(config['cfl']), 0.
        for snapshot in range(config['snapshots']):
            # First-stage candidate from an SSP-RK trajectory. The one-time
            # intervention is followed by h complete guard-only RK steps.
            candidate = u+dt*solver.rhs(u, t)
            final_t = t+dt*(1+config['horizon_steps'])
            x, cost, baseline = operator.action_costs(
                candidate, dt, q, lambda x, y: reference(x, y, final_t),
                actions=config['actions'], horizon=config['horizon_steps'])
            features.append(x)
            costs.append(cost)
            groups.extend([group]*solver.K)
            area.extend(solver.mesh.areas)
            records.append({'group':group, 'snapshot':snapshot, 'time':t, 'dt':dt,
                            'cells':solver.K, 'baseline_global_l2_squared':baseline,
                            'best_single_cell_improvement':float(np.max(cost[:, 0]-cost.min(axis=1))),
                            'beneficial_cell_fraction':float(np.mean(cost.min(axis=1) < cost[:, 0]-1e-12))})
            # Evolve the same trajectory under the behavior policy. Stage
            # times are immaterial here because velocity/boundaries are static.
            duration = config['snapshot_spacing_steps']*dt
            u, _ = solver.solve_guarded(u, duration, controller, cfl=config['cfl'])
            t += duration
        print(f'data group {group+1}/{count}, {time.perf_counter()-started:.2f}s', flush=True)
    data = dict(x=np.concatenate(features), costs=np.concatenate(costs),
                groups=np.asarray(groups), areas=np.asarray(area))
    np.savez_compressed(out/'data.npz', **data)
    write_json(out/'oracle-records.json', records)
    return data


def fit(out, data, config, seeds):
    out.mkdir(parents=True, exist_ok=True)
    train = data['groups'] < config['train_trajectories']
    val = ~train
    center = data['x'][train].mean(axis=0)
    scale = np.maximum(data['x'][train].std(axis=0), .01)
    advantages = (data['costs'][:, :1]-data['costs'][:, 1:])/data['areas'][:, None]
    targets = np.clip(advantages/config['score_scale'], -100., 100.)
    x = torch.tensor((data['x']-center)/scale, dtype=torch.float32)
    y = torch.tensor(targets, dtype=torch.float32)
    # Equal trajectory weight; larger meshes and extra on-policy snapshots
    # do not automatically increase a trajectory's influence.
    weights = np.zeros(len(x))
    for group in np.unique(data['groups']):
        mask = data['groups'] == group
        weights[mask] = 1/mask.sum()
    wt = torch.tensor(weights, dtype=torch.float32)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    summaries = []
    for seed in seeds:
        torch.manual_seed(seed)
        model = nn.Sequential(nn.Linear(12, config['hidden_width']), nn.ReLU(), nn.Linear(config['hidden_width'], 3))
        nn.init.zeros_(model[2].weight)
        nn.init.constant_(model[2].bias, -config['advantage_margin'])
        optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
        best = None
        for epoch in range(config['epochs']):
            prediction = model(x[train])
            per_row = ((prediction-y[train])**2).mean(axis=1)
            loss = (wt[train]*per_row).sum()/wt[train].sum()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            with torch.no_grad():
                scores = model(x[val]).numpy()
            choices = scores.argmax(axis=1)+1
            choices[scores.max(axis=1) <= config['advantage_margin']] = 0
            all_gains = np.column_stack([np.zeros(val.sum()), advantages[val]])
            regret = all_gains.max(axis=1)-all_gains[np.arange(val.sum()), choices]
            metric = float(np.average(regret, weights=weights[val]))
            mse = float(np.average(np.mean((scores-targets[val])**2, axis=1), weights=weights[val]))
            key = (metric, mse)
            if best is None or key < best[0]:
                best = (key, epoch+1, {k:v.detach().clone() for k,v in model.state_dict().items()})
        model.load_state_dict(best[2])
        path = out/f'seed-{seed}.npz'
        np.savez(path, schema_version=1, w1=model[0].weight.detach().numpy(), b1=model[0].bias.detach().numpy(),
                 w2=model[2].weight.detach().numpy(), b2=model[2].bias.detach().numpy(), center=center, scale=scale,
                 actions=np.asarray(config['actions'][1:]), margin=config['advantage_margin'])
        portable = RolloutSlopeModel(path)
        with torch.no_grad():
            exported = np.maximum(((data['x']-center)/scale)@portable.w1.T+portable.b1, 0)@portable.w2.T+portable.b2
            np.testing.assert_allclose(exported, model(x).numpy(), atol=1e-4, rtol=1e-5)
        summaries.append({'seed':seed, 'best_epoch':best[1], 'validation_action_regret':best[0][0],
                          'validation_score_mse':best[0][1], 'checkpoint':path.name,
                          'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    noop_regret = np.maximum(advantages[val].max(axis=1), 0)
    write_json(out/'training.json', {'models':summaries,
                'guard_only_validation_regret':float(np.average(noop_regret, weights=weights[val])),
                'train_rows':int(train.sum()), 'validation_rows':int(val.sum())})
    return summaries


def evaluation_cases(config):
    for n in config['smooth_resolutions']:
        solver = AdvectionDG2D(rectangular_mesh(nx=n, ny=n), velocity=(-.65, .4), periodic=(True, True))
        def smooth(x, y, t):
            return .5+.25*np.cos(2*np.pi*(x+.65*t))*np.sin(2*np.pi*(y-.4*t))
        yield 'smooth', 'structured', n, solver, smooth, .1
    for n in config['evaluation_resolutions']:
        for mesh_type in ['structured', 'delaunay']:
            mesh = (rectangular_mesh(nx=n, ny=n) if mesh_type == 'structured' else
                    perturbed_delaunay_mesh(nx=n, ny=n, jitter=.28, seed=config['evaluation_mesh_seed']))
            solver = AdvectionDG2D(mesh, velocity=(-.7, .35), periodic=(True, True))
            def pulses(x, y, t):
                xx, yy = (x+.7*t) % 1, (y-.35*t) % 1
                a = ((xx > .13) & (xx < .24) & (yy > .18) & (yy < .62))
                b = ((xx-.68)**2+(yy-.71)**2 < .11**2)
                return .8*a.astype(float)+.6*b.astype(float)
            yield 'two-pulses', mesh_type, n, solver, pulses, .3
            rotation = AdvectionDG2D(mesh, velocity=rotational_velocity,
                                     boundary_func=lambda x, y, t: np.zeros_like(x))
            def rotating_slot(x, y, t):
                angle = -2*np.pi*t
                xx = .5+np.cos(angle)*(x-.5)-np.sin(angle)*(y-.5)
                yy = .5+np.sin(angle)*(x-.5)+np.cos(angle)*(y-.5)
                disk = (xx-.64)**2+(yy-.65)**2 <= .135**2
                slot = (np.abs(yy-.65) < .035) & (xx >= .64)
                return (disk & ~slot).astype(float)
            yield 'rotated-slot', mesh_type, n, rotation, rotating_slot, .5


def evaluate(out, config, models):
    methods = [('guard-only', None), ('mrs', MRSSlopeProposal(config['mrs_coefficient'])), ('jump-prior', jump_prior)]
    methods += [(f'rollout-{row["seed"]}', RolloutSlopeModel(out/'models'/row['checkpoint'])) for row in models]
    rows = []
    (out/'fields').mkdir()
    for problem, mesh, n, solver, exact, final_time in evaluation_cases(config):
        q = TriangleQuadrature(solver.mesh, config['quadrature_order'], config['quadrature_subdivisions'])
        finer = TriangleQuadrature(solver.mesh, config['quadrature_order'], config['quadrature_subdivisions']+1)
        initial_controller = GuardedSlopeLimiter(0, 1)
        initial, _ = initial_controller.apply(solver, finer.project(lambda x, y: exact(x, y, 0)), initial=True)
        for method, proposal in methods:
            row = dict(problem=problem, mesh=mesh, n=n, method=method, final_time=final_time)
            controller = GuardedSlopeLimiter(0, 1, proposal)
            started = time.perf_counter()
            try:
                result, history = solver.solve_guarded(initial, final_time, controller,
                            cfl=config['cfl'], max_seconds=config['maximum_seconds_per_run'])
                row['runtime_s'] = time.perf_counter()-started
                stages = [stage for step in history for stage in step['stages']]
                coarse = q.errors(result, lambda x, y: exact(x, y, final_time))
                accurate = finer.errors(result, lambda x, y: exact(x, y, final_time))
                row.update(status='ok', l1=accurate['l1'], l2=accurate['l2'],
                    l1_quadrature_relative_change=abs(accurate['l1']-coarse['l1'])/max(accurate['l1'],1e-15),
                    stage_minimum=min(s['minimum'] for s in stages), stage_maximum=max(s['maximum'] for s in stages),
                    mean_damping=float(np.mean([s['mean_damping'] for s in stages])),
                    limited_fraction=float(np.mean([s['limited_fraction'] for s in stages])),
                    mass_change=solver.integral(result)-solver.integral(initial),
                    boundary_transport=controller.boundary_transport,
                    conservation_residual=solver.integral(result)-solver.integral(initial)-controller.boundary_transport,
                    rejected_steps=controller.rejected_steps, invalid_predictions=controller.invalid_predictions)
                field_name=f'{problem}-{mesh}-{n}-{method}.npz'
                np.savez_compressed(out/'fields'/field_name, points=solver.mesh.points, cells=solver.mesh.cells,
                                    initial=initial, result=result)
                row['field']=f'fields/{field_name}'
                row['field_sha256']=hashlib.sha256((out/row['field']).read_bytes()).hexdigest()
            except (ValueError, RuntimeError, TimeoutError) as error:
                row.update(status='failed', error=f'{type(error).__name__}: {error}', runtime_s=time.perf_counter()-started)
            rows.append(row)
            write_json(out/'evaluation.json', rows)
            print(json.dumps(row), flush=True)
    return rows


def summarize(out, config, rows):
    controls = {(r['problem'],r['mesh'],r['n']):r for r in rows if r['method']=='guard-only' and r['status']=='ok'}
    summary={'attempts':len(rows), 'failures':sum(r['status']!='ok' for r in rows), 'seeds':[]}
    gates=config['acceptance']
    for seed in config['initialization_seeds']:
        selected=[r for r in rows if r['method']==f'rollout-{seed}']
        if any(r['status']!='ok' for r in selected):
            summary['seeds'].append({'seed':seed,'accepted':False,'reason':'failed evaluation'})
            continue
        sharp=[r for r in selected if r['problem']!='smooth']
        smooth=sorted([r for r in selected if r['problem']=='smooth'],key=lambda r:r['n'])
        ratios=[r['l1']/controls[(r['problem'],r['mesh'],r['n'])]['l1'] for r in sharp]
        runtimes=[r['runtime_s']/controls[(r['problem'],r['mesh'],r['n'])]['runtime_s'] for r in selected]
        order=float(np.log(smooth[-2]['l2']/smooth[-1]['l2'])/np.log(smooth[-1]['n']/smooth[-2]['n']))
        record={'seed':seed,'mean_relative_sharp_l1_improvement':float(1-np.mean(ratios)),
                'worst_case_l1_ratio':max(ratios),'mean_runtime_ratio':float(np.mean(runtimes)),
                'final_smooth_order':order,
                'max_bound_violation':max(max(0,-r['stage_minimum'],r['stage_maximum']-1) for r in selected),
                'max_conservation_residual':max(abs(r['conservation_residual']) for r in selected),
                'max_relative_l1_quadrature_change':max(r['l1_quadrature_relative_change'] for r in selected)}
        checks={'bounds':record['max_bound_violation']<=gates['max_bound_violation'],
                'conservation':record['max_conservation_residual']<=gates['max_conservation_residual'],
                'smooth_order':order>=gates['minimum_final_smooth_order'],
                'improvement':record['mean_relative_sharp_l1_improvement']>=gates['minimum_mean_relative_l1_improvement_over_guard'],
                'regression':record['worst_case_l1_ratio']<=1+gates['maximum_case_l1_regression'],
                'runtime':record['mean_runtime_ratio']<=gates['maximum_mean_runtime_ratio_to_guard'],
                'quadrature':record['max_relative_l1_quadrature_change']<=gates['max_relative_l1_quadrature_change']}
        record.update(checks=checks,accepted=all(checks.values()))
        summary['seeds'].append(record)
    summary['adopt']=summary['failures']==0 and all(r['accepted'] for r in summary['seeds'])
    write_json(out/'summary.json',summary)
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path('configs/rollout-limiter-v1.json'))
    parser.add_argument('--out',type=Path,default=Path('runs/rollout-limiter-v1'))
    args=parser.parse_args()
    if args.out.exists():
        raise SystemExit('Output directory already exists; use a new directory to preserve frozen evidence.')
    config=json.loads(args.config.read_text())
    args.out.mkdir(parents=True)
    source=args.out/'source'; source.mkdir()
    paths=[args.config,Path(__file__).resolve().relative_to(Path.cwd()),*Path('tci').rglob('*.py')]
    hashes={}
    for path in paths:
        target=source/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
        hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    write_json(args.out/'manifest.json',{'config':config,'source_sha256':hashes,
        'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'python':platform.python_version(),'numpy':np.__version__,'torch':torch.__version__})
    original=args.out/'guard-data'; original.mkdir()
    data=collect(original,config)
    provisional=fit(args.out/'behavior-model',data,config,[config['on_policy_behavior_seed']])
    behavior=RolloutSlopeModel(args.out/'behavior-model'/provisional[0]['checkpoint'])
    extra=args.out/'on-policy-data';extra.mkdir()
    extra_data=collect(extra,config,behavior,training_only=True)
    combined={k:np.concatenate([data[k],extra_data[k]]) for k in data}
    models=fit(args.out/'models',combined,config,config['initialization_seeds'])
    # Immutable model manifest is written before opening the fresh final cases.
    write_json(args.out/'frozen-models.json',models)
    rows=evaluate(args.out,config,models)
    print(json.dumps(summarize(args.out,config,rows),indent=2),flush=True)


if __name__=='__main__':
    main()
