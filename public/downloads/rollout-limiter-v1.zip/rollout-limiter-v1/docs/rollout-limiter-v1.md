# Improving the limiter: solver-aware decisions and stronger evidence

The highest-priority change was to train for the consequence of a decision.
A coefficient that matches a reference slope now can damage neighboring cell
means a few stages later. The previous scalar regressor had no way to observe
that consequence. A second priority was reliable evaluation: the previous
P1-to-P1 error omitted reference interpolation error, and rotation mass change
was not separated from boundary flux.

This iteration implements all three improvements and keeps the numerical bound
guard. It is a controlled scalar P1 experiment, not an Euler result or a claim
of publication-ready superiority.

## What changed

- `tci/quadrature.py`: positive composite Gauss quadrature over affine triangles,
  approximate L2 projection for initialization, and L1/L2 errors against the
  analytic field. Discontinuous references are checked at two subdivision levels.
  Their quadrature errors are estimates, not exact interface integration.
- `AdvectionDG2D.boundary_mass_rate`: independently sums the same numerical
  boundary flux as the spatial operator. Guarded SSP-RK3 integrates it using the
  RK weights, so reported conservation residual is mass change minus transport.
- `tci/rollout.py`: batched copies of the existing periodic linear DG operator
  generate counterfactual action costs. Independent tests compare both their
  solutions and action costs with the production solver.
- `RolloutSlopeModel`: predicts the advantage of each nonzero damping action
  relative to no added damping. An explicit no-op has advantage zero. The policy
  chooses a nonzero action only if its predicted advantage exceeds the frozen
  margin. That score margin has no role in admissibility; the physical guard
  remains unconditional.
- `MRSSlopeProposal`: a scalar P1 specialization of the local-extrema construction
  in [Moe–Rossmanith–Seal](https://arxiv.org/abs/1507.03024), with face neighbors,
  h equal to maximum edge length, alpha=h^1.5 and cutoff min(r/1.1,1). The physical
  guard is applied afterwards. This frozen unit-domain specialization has not
  been tuned to reproduce the paper's benchmark results.

## Training experiment, fixed before evaluation

The complete configuration is `configs/rollout-limiter-v1.json`. Its source and
configuration snapshots are under `runs/rollout-limiter-v1/source/`, with hashes
in `manifest.json`. Model hashes are written to `frozen-models.json` before the
final cases are evaluated. Existing output directories cannot be overwritten.

There are 24 training and eight validation trajectories. Each uses a distinct
random seed derived from 20260909. Training fields are sine products, boxes,
disks and smooth tanh layers. Meshes are structured or perturbed Delaunay at
n=6,8. Mesh assignments vary across field families. Every snapshot and every
counterfactual branch of a trajectory stays in its trajectory's split.

For each snapshot:

1. Form a first-stage candidate from the current SSP-RK trajectory.
2. For each cell, compare a one-time damping action a in {0,0.25,0.5,1} with no
   extra damping. The coefficient is `1-min(J,1)^2*a`, intersected with the
   physical bound coefficient. J is the normalized paired face-trace jump.
3. Evolve four complete RK steps under the guard only. Score the area-integrated
   squared error against the analytic reference using quadrature moments.
4. Store all action costs, not just the winning label. Interventions affect
   neighbors during the rollout. Cases where the physical guard already dominates
   all available actions are recognized as exact ties.

These are **single-cell counterfactual costs**. Combining their individual
optima is not a jointly optimal policy. The continuation is guard-only and the
observation is a first-stage candidate; other-stage deployment and longer learned
rollouts remain a modeling approximation.

A provisional seed-0 policy is trained first. It generates a second batch of
states on the training trajectories only. The original guard-generated data and
these on-policy states are combined; validation trajectories are not regenerated
or added to training. Five final initialization seeds share this dataset.

The regressor uses 12 invariant local features, one 24-unit ReLU hidden layer,
and three action-advantage outputs. Features are standardized using training rows
only. Costs are scaled by cell area and 1e-6, then clipped to [-100,100] for the
regression loss. Trajectories receive equal total training weight. Best checkpoints
minimize validation decision regret, with score MSE breaking ties. No checkpoint
is selected using the final evaluation. The no-op margin is 0.01 in scaled units.

The oracle diagnostic shows whether the available local action can help, not
whether the learned controller will improve a full simulation. Similarly,
reduced validation regret is an intermediate measure, not the final result.

## Fresh evaluation and acceptance

The final suite uses resolutions and parameters absent from training and the
previous pilot: smooth advection at n=12,24,48; two separated pulses and a shifted,
rotated slotted disk at n=14,22 on structured and Delaunay meshes (seed 903,
jitter 0.28). The pulses translate with reversed x-velocity; the disk rotates for
half a revolution. Exact references are known analytically.

All methods start from the same quadrature-projected and guarded initial state,
use the same P1 spatial operator, SSP-RK3, CFL=0.15 and physical bounds [0,1].
Controls are guard-only, the MRS specialization plus guard, and the deterministic
jump prior plus guard. Five rollout-trained policies are evaluated separately:
11 cases × 8 methods = 88 attempts. Per-run deadline is 90 seconds. Final fields,
meshes, per-run metrics and hashes are saved so norms can be rechecked.

Errors are calculated with six-point Gauss rules in each Duffy coordinate over
64 subtriangles per physical triangle and compared with 16-subtriangle estimates.
The L1 change must be <=1% for the acceptance gate. A shared quadrature bias at
both levels is still possible for a discontinuous interface. Smooth fields have
far smaller quadrature sensitivity; their final refinement rate uses true
analytic-reference L2 errors, including projection error.

The frozen gates require every seed to have: accepted-stage bound violation
<=1e-12; boundary-accounted conservation residual <=1e-10; final smooth order
>=1.8; mean paired sharp-case L1 improvement over guard-only >=10%; no sharp
case more than 5% worse; mean paired runtime ratio <=1.25; and the quadrature
check above. Every failure is retained. No post-evaluation threshold adjustment
or favorable-seed promotion is allowed.

## Reproduce

```bash
python -m pip install -e '.[ml,dev]'
python -m pytest -q
python scripts/train_rollout_limiter.py --out runs/rollout-limiter-v1
```

Use a different output directory for an additional run. The archive preserves
both source snapshots and the consolidated implementation; the snapshot is the
source of record for this experiment. Inference requires only NumPy:

```python
from tci.guarded import GuardedSlopeLimiter
from tci.rollout import RolloutSlopeModel

policy = RolloutSlopeModel('runs/rollout-limiter-v1/models/seed-0.npz')
controller = GuardedSlopeLimiter(0., 1., proposal=policy)
u, stages = solver.solve_guarded(u0, final_time=.3, controller=controller)
```

## Research interpretation

Solver-aware training is itself established prior work; for example,
[Caldana, Antonietti and Dedè's DG viscosity study](https://doi.org/10.1016/j.jcp.2024.113476)
trains against reference-solution error through a solver. This experiment tests
a small, inspectable counterfactual alternative for the existing codebase.
Its potential contribution would require an actual advantage over equally guarded
controls, not merely the use of rollout labels, a neural model or numerical bounds.

## Completed result: retain the guard, reject this learned policy

All **88/88 runs completed**, with no timeouts or numerical failures. Across all
methods, maximum accepted-stage violation was 2.78e-17, and maximum
boundary-accounted conservation residual was 7.76e-15. The largest L1 quadrature
change was 0.104%, below the frozen 1% gate. Smooth final refinement rates were
1.998 for guard-only and 1.998 (approximately, all five seeds) for rollout ML.
The frozen MRS specialization had a 1.034 rate over this range; it is still
limiting smooth extrema on these meshes, so it is not a successful
accuracy-preserving reference at this operating point.

| Analytic-reference L1, five-seed ML mean | Guard only | Rollout ML | Change in error |
|---|---:|---:|---:|
| Two pulses, structured n=22 | 0.027536 | 0.027485 | -0.18% |
| Two pulses, Delaunay n=22 | 0.028269 | 0.028695 | +1.51% |
| Rotated slot, structured n=22 | 0.029336 | 0.034949 | +19.13% |
| Rotated slot, Delaunay n=22 | 0.029025 | 0.038218 | +31.67% |

The isolated 0.18% improvement is too small to carry a superiority claim and is
not robust across the suite. Across the eight sharp cases, each seed's mean
relative error increase ranged from 2.00% to 17.92%. Mean paired runtime ratios
were 1.94–1.97. **All five seeds fail the accuracy improvement, worst-case
regression, and runtime gates.** The frozen acceptance decision is `adopt: false`.
No seed is promoted and no threshold is changed after these results.

The oracle diagnostic is more informative than an offline classification score:
about 30.1% of guard-generated candidate cells and 28.6% of behavior-policy
candidate cells had a positive single-cell action gain above 1e-12. The largest
single-cell gain in these samples was only 0.473% of total reference error.
That is evidence of some local opportunity; it is not an upper bound on a
joint policy's benefit. Final validation regret decreased modestly relative to
the no-op control, but those gains did not transfer to full rotation trajectories.

The practical improvements delivered here are verified true-reference error
measurement, boundary-flux conservation accounting, on-policy state collection,
rollout-based cost data, independent oracle tests, and immutable experiment
snapshots. The learned model itself has not earned adoption.

The next research priority is the **action space and continuation model**:

- Current actions can only reduce the candidate slope. Guard-only already takes
  the least-damped point on that same ray that satisfies the prescribed bounds.
  Additional damping can still suppress in-bound oscillations, but cannot restore
  information already lost to diffusion.
- A mean-preserving reconstruction or a conservative flux correction could offer
  useful actions beyond extra damping. First test a numerical oracle and a strong
  deterministic reconstruction under the same bounds; only learn a selector if
  that test shows material headroom.
- Four guard-only continuation steps do not capture repeated learned decisions
  over a half revolution. A longer, jointly applied rollout objective is another
  separate experiment. The present result does not prove that longer rollouts,
  directional features, or alternative losses cannot help.

This would be a new method and a new frozen evaluation, not a reinterpretation
of these rejected results. The current usable recommendation remains the scalar
P1 guard-only path within its stated bounds/CFL/boundary assumptions.
