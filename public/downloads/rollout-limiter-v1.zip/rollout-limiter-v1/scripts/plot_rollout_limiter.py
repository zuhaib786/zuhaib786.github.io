#!/usr/bin/env python
"""Plot completed frozen rollout results without selecting favorable seeds."""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run',type=Path,default=Path('runs/rollout-limiter-v1'))
parser.add_argument('--out',type=Path,default=Path('docs/figures/rollout-limiter-v1'))
args=parser.parse_args()
rows=json.loads((args.run/'evaluation.json').read_text())
if len(rows)!=88 or any(r['status']!='ok' for r in rows):
    raise SystemExit('This figure requires the complete 88-run experiment; inspect failed rows separately.')
args.out.parent.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                     'axes.spines.right':False,'svg.fonttype':'none'})
fig,(left,right)=plt.subplots(1,2,figsize=(13,5),gridspec_kw={'width_ratios':[1,1.5]})
colors={'guard-only':'#164b35','mrs':'#ac5f31','jump-prior':'#777777','ML':'#275eaa'}
for method,label in [('guard-only','Guard only'),('mrs','MRS + guard'),('jump-prior','Jump rule + guard')]:
    r=sorted([r for r in rows if r['problem']=='smooth' and r['method']==method],key=lambda r:r['n'])
    left.loglog([v['n'] for v in r],[v['l2'] for v in r],marker='o',label=label,color=colors[method])
ns=[12,24,48]
values=np.array([[next(r['l2'] for r in rows if r['problem']=='smooth' and r['n']==n and r['method']==f'rollout-{seed}') for n in ns] for seed in range(5)])
left.errorbar(ns,values.mean(axis=0),yerr=values.std(axis=0,ddof=1),label='Rollout ML, mean ± SD',color=colors['ML'],marker='x',linestyle='--',capsize=4)
left.set_xticks(ns,labels=ns);left.minorticks_off()
left.set_xlabel('Mesh resolution n');left.set_ylabel('Analytic-reference L² error')
left.set_title('Smooth accuracy is preserved',loc='left',pad=15)
left.grid(alpha=.18);left.legend(frameon=False,fontsize=8)
cases=[(problem,mesh,n) for problem in ['two-pulses','rotated-slot'] for n in [14,22] for mesh in ['structured','delaunay']]
for i,case in enumerate(cases):
    rs=[r for r in rows if (r['problem'],r['mesh'],r['n'])==case]
    base=next(r['l1'] for r in rs if r['method']=='guard-only')
    ml=np.array([r['l1']/base for r in rs if r['method'].startswith('rollout-')])
    right.scatter(i+np.linspace(-.12,.12,5),ml,color=colors['ML'],s=20,alpha=.65)
    right.errorbar(i,ml.mean(),yerr=ml.std(ddof=1),color=colors['ML'],fmt='_',markersize=14,capsize=4)
    for method,marker,shift in [('mrs','s',.22),('jump-prior','^',-.22)]:
        ratio=next(r['l1']/base for r in rs if r['method']==method)
        right.scatter(i+shift,ratio,color=colors[method],marker=marker,s=24,
                      label={'mrs':'MRS + guard','jump-prior':'Jump rule + guard'}[method] if i==0 else None)
right.axhline(1,color=colors['guard-only'],linewidth=1.5,label='Guard-only reference')
right.axvline(3.5,color='#dddddd',linewidth=1)
right.set_xticks(range(8),labels=[f'{"S" if mesh=="structured" else "D"}{n}' for _,mesh,n in cases])
right.set_xlabel('Translated pulses                            Rotated slotted disk\nS: structured; D: Delaunay')
right.set_ylabel('L¹ error / guard-only L¹ error (lower is better)')
right.set_title('Local decisions do not yield a robust ML gain',loc='left',pad=15)
right.grid(axis='y',alpha=.18)
right.scatter([],[],color=colors['ML'],label='Rollout ML: all five seeds',s=20)
right.legend(frameon=False,fontsize=8,loc='upper left')
fig.suptitle('Guarded limiter · frozen 88-run evaluation',fontsize=15,x=.07,ha='left')
fig.text(.07,.018,'All methods use the same physical bound guard. ML bars: mean ± sample SD. No seed selected or omitted.',fontsize=9,color='#444444')
fig.tight_layout(rect=[0,.055,1,.94])
fig.savefig(args.out.with_suffix('.png'),dpi=180,facecolor='white')
fig.savefig(args.out.with_suffix('.svg'),facecolor='white')
print(args.out.with_suffix('.png'))
